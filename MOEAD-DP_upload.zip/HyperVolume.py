import GlobalValues as gv
import pickle
from scipy.linalg import solve
import numpy as np
# import geatpy as ea
class Utils:
    @staticmethod
    def is_dominate(obj_a, obj_b, num_obj, ):  # a dominates b
        if type(obj_a) is not np.ndarray:
            obj_a, obj_b = np.array(obj_a), np.array(obj_b)
        res = np.array([np.sign(k) for k in obj_a - obj_b])
        res_ngt0, res_eqf1 = np.argwhere(res <= 0), np.argwhere(res == -1)
        if res_ngt0.shape[0] == num_obj and res_eqf1.shape[0] > 0:
            return True
        return False
class Pareto:
    def __init__(self, pop_size, pop_obj, ):
        self.pop_size = pop_size
        self.pop_obj = pop_obj
        self.num_obj = pop_obj.shape[1]
        self.f = []
        self.sp = [[] for _ in range(pop_size)]
        self.np = np.zeros([pop_size, 1], dtype=int)
        self.rank = np.zeros([pop_size, 1], dtype=int)
        self.cd = np.zeros([pop_size, 1])

    def __index(self, i, ):
        return np.delete(range(self.pop_size), i)

    def __is_dominate(self, i, j, ):
        return Utils.is_dominate(self.pop_obj[i], self.pop_obj[j], self.num_obj)

    def __f1_dominate(self, ):
        f1 = []
        for i in range(self.pop_size):
            for j in self.__index(i):
                # print(i,' ',j,'\n')
                if self.__is_dominate(i, j):
                    if j not in self.sp[i]:
                        self.sp[i].append(j)
                elif self.__is_dominate(j, i):
                    self.np[i] += 1
            if self.np[i] == 0:
                self.rank[i] = 1
                f1.append(i)
        return f1

    def fast_non_dominate_sort(self, ):
        rank = 1
        f1 = self.__f1_dominate()
        while f1:
            self.f.append(f1)
            q = []
            for i in f1:
                for j in self.sp[i]:
                    self.np[j] -= 1
                    if self.np[j] == 0:
                        self.rank[j] = rank + 1
                        q.append(j)
            rank += 1
            f1 = q

    def sort_obj_by(self, f=None, j=0, ):
        if f is not None:
            index = np.argsort(self.pop_obj[f, j])
        else:
            index = np.argsort(self.pop_obj[:, j])
        return index

    def crowd_distance(self, ):
        for f in self.f:
            len_f1 = len(f) - 1
            for j in range(self.num_obj):
                index = self.sort_obj_by(f, j)
                sorted_obj = self.pop_obj[f][index]
                obj_range_fj = sorted_obj[-1, j] - sorted_obj[0, j]
                self.cd[f[index[0]]] = np.inf
                self.cd[f[index[-1]]] = np.inf
                for i in f:
                    k = np.argwhere(np.array(f)[index] == i)[:, 0][0]
                    if 0 < index[k] < len_f1:
                        self.cd[i] += (sorted_obj[index[k] + 1, j] - sorted_obj[index[k] - 1, j]) / obj_range_fj
class indicator:
    # def __init__(self, pop_size, pop_obj, ):
    def HV(S,rf=np.array([[1,1]])):
        r = ndsortTNS(S, 1)[0]
        index = np.where(r == 1)[0]
        # print(S)
        S = S[index]
        # print(S)
        rf = rf[0]
        S = S[np.lexsort(S[:,::-1].T)]
        # print(S)
        res = 0
        for i in range(len(S)-1):
            res = res + (np.abs(S[i+1][0]-S[i][0]) * (rf[1]-S[i][1]))
        last_s = S[len(S)-1]
        res = res + (rf[1]-last_s[1])*(rf[0]-last_s[0])
        return res

def ndsortTNS(S,r):
    ind = Pareto(len(S), S)
    ind.fast_non_dominate_sort()
    # index = np.where(ind.rank !=r)
    # ind.rank[index] = np.inf
    return np.array(np.array(ind.rank).T)

if __name__ == "__main__":

    # gv.rf = np.array([[3,3]])
    S = np.array([np.array([0.1,0.2]),np.array([0.2,0.18]),np.array([0.3,0.5]),np.array([0.4,0.6])])
    # ind = indicator(3,S)
    r1 = indicator.HV(S,gv.rf)
    # ind.fast_non_dominate_sort()
    # rrr = ea.ndsortTNS(S, 1)[0]
    r_DPS = ndsortTNS(S, 1)[0]
    index = np.where(r_DPS==1)[0]
    # index_ = np.where(rrr==1)[0]