
import pickle

import GlobalValues as gv
import numpy as np
import geatpy as ea
from matplotlib import pyplot as plt
def median(a):
    b = np.argsort(a)
    return b[int(len(b)/2)]
if __name__ == "__main__":
#  Performance of four algorithms on the proposed model in terms of the mean $I_H$ values

    stepLength = 199
    T = 6
    maxGeneration = 200
    read_Dir = '../ANOVA/'
    read_Dir2 = ''
    Dir = '../ANOVA/'
    Dir2 = 'plot/'
    maxrun = 10
    data_lambda=list()
    data_theta = list()
    data_R = list()
    data_res = list()
    data_alg = list()
    data_count = list()
    alg=np.array(['TMOEA/D-DP','MOEA/D-SF','MOEA/D-WF','FSF-DP'])#,'FSF-WF','FSF-SF'
    sample_size = 135
    for count in range(700,836):
        HV_list_DPS = list()
        for run in range(1,maxrun+1):
            f = open('./' + read_Dir + read_Dir2 + 'DPS_' + str(count) + '_' + str(run) + ".txt", 'rb')
            ([res_ind_DPS, res_f_DPS, res_DPS, Mu, gv.Lambda, gv.R, gv.Thet]) = pickle.load(f)
            f.close()
            HV_list_DPS.append(ea.indicator.HV(res_DPS,gv.rf))
        median_run = median(HV_list_DPS)+1
        f = open('./' + read_Dir + read_Dir2 + 'DPS_' + str(count) + '_' + str(median_run) + ".txt",'rb')
        ([res_ind_DPS, res_f_DPS, res_DPS, Mu, gv.Lambda, gv.R, gv.Thet]) = pickle.load(f)
        f.close()
        N = len(Mu)

        f = open('./AC/'+str(Dir)+'FSF_dp_' + str(count) + ".txt", 'rb')
        ([Mu, gv.Lambda, gv.R, gv.Thet, res_FSF_dp]) = pickle.load(f)
        r = ea.ndsortTNS(res_FSF_dp, 1)[0]
        index = np.where(r == 1)[0]
        res_FSF_dp = res_FSF_dp[index]
        f.close()

        HV_list = list()
        for run in range(1,maxrun+1):
            f = open('./AC/' + str(Dir) + 'SFS_' + str(count)+"_"+str(run) + ".txt", 'rb')
            ([Mu, gv.Lambda, gv.R, gv.Thet, res_SFS,_]) = pickle.load(f)
            f.close()
            HV_list.append(ea.indicator.HV(res_SFS,gv.rf))
        median_run = median(HV_list)+1
        f = open('./AC/' + str(Dir) + 'SFS_' + str(count)+"_"+str(median_run) + ".txt", 'rb')
        ([Mu, gv.Lambda, gv.R, gv.Thet, res_SFS,_]) = pickle.load(f)
        r = ea.ndsortTNS(res_SFS, 1)[0]
        index = np.where(r == 1)[0]
        res_SFS = res_SFS[index]
        f.close()

        HV_list = list()
        for run in range(1,maxrun+1):
            f = open('./AC/' + str(Dir) + 'WFS_' + str(count)+"_"+str(run) + ".txt", 'rb')
            ([Mu, gv.Lambda, gv.R, gv.Thet, res_WFS,_]) = pickle.load(f)
            f.close()
            HV_list.append(ea.indicator.HV(res_WFS,gv.rf))
        median_run = median(HV_list)+1
        f = open('./AC/' + str(Dir) + 'WFS_' + str(count)+"_"+str(median_run) + ".txt", 'rb')
        ([Mu, gv.Lambda, gv.R, gv.Thet, res_WFS,_]) = pickle.load(f)
        r = ea.ndsortTNS(res_WFS, 1)[0]
        index = np.where(r == 1)[0]
        res_WFS = res_WFS[index]
        f.close()

        for alg_name in alg:
            data_theta.append(gv.Thet)
            data_lambda.append(gv.Lambda)
            data_R.append(gv.R)
            data_alg.append(alg_name)
            data_count.append(count)
        # 'MOEA/D-DP', 'MOEA/D-SFS', 'MOEA/D-WFS', 'FSF-DP', 'FSF-WFS', 'FSF-SFS']
        data_res.append(ea.indicator.HV(res_DPS,gv.rf))
        data_res.append(ea.indicator.HV(res_SFS, gv.rf))
        data_res.append(ea.indicator.HV(res_WFS, gv.rf))
        data_res.append(ea.indicator.HV(res_FSF_dp, gv.rf))
        # data_res.append(ea.indicator.HV(res_FSF_WFS,gv.rf))
        # data_res.append(ea.indicator.HV(res_FSF_SFS, gv.rf))
    for algorithm in alg:
        print('\n \multirow{2}[0]{*}{',algorithm,'} & mean  ',end='')
        index1 = np.where((np.array(data_lambda) >0)  &(np.array(data_lambda) <= 45) & (np.array(data_theta) >0) & (
                np.array(data_theta) <= 45) & (np.array(data_alg)==algorithm))
        index2 = np.where((np.array(data_lambda) > 0) & (np.array(data_lambda) <= 45) & (np.array(data_theta) > 45) & (
                    np.array(data_theta) <= 90) & (np.array(data_alg)==algorithm) )
        index3 = np.where((np.array(data_lambda) > 0) & (np.array(data_lambda) <= 45) & (np.array(data_theta) > 90) & (
                    np.array(data_theta) <= 135) & (np.array(data_alg)==algorithm) )
        index4 = np.where((np.array(data_lambda) > 45) & (np.array(data_lambda) <= 90) & (np.array(data_theta) > 0) & (
                    np.array(data_theta) <= 45) & (np.array(data_alg)==algorithm) )
        index5 = np.where((np.array(data_lambda) > 45) & (np.array(data_lambda) <= 90) & (np.array(data_theta) > 45) & (
                    np.array(data_theta) <= 90) & (np.array(data_alg)==algorithm) )
        index6 = np.where((np.array(data_lambda) > 45) & (np.array(data_lambda) <= 90) & (np.array(data_theta) > 90) & (
                    np.array(data_theta) <= 135) & (np.array(data_alg)==algorithm) )
        index7 = np.where((np.array(data_lambda) > 90) & (np.array(data_lambda) <= 135) & (np.array(data_theta) > 0) & (
                    np.array(data_theta) <= 45) & (np.array(data_alg)==algorithm) )
        index8  = np.where((np.array(data_lambda) > 90) & (np.array(data_lambda) <= 135) & (np.array(data_theta) > 45) & (
                    np.array(data_theta) <= 90) & (np.array(data_alg)==algorithm) )
        index9 =np.where((np.array(data_lambda) > 90) & (np.array(data_lambda) <= 135) & (np.array(data_theta) > 90) & (
                    np.array(data_theta) <= 135) & (np.array(data_alg)==algorithm) )
        index10 = np.where((np.array(data_lambda) > 135) & (np.array(data_lambda) <= 180) & (np.array(data_theta) > 0) & (
                np.array(data_theta) <= 45) & (np.array(data_alg)==algorithm) )
        index11 = np.where((np.array(data_lambda) > 135) & (np.array(data_lambda) <= 180) & (np.array(data_theta) > 45) & (
                np.array(data_theta) <= 90) & (np.array(data_alg)==algorithm) )
        index12 = np.where((np.array(data_lambda) > 135) & (np.array(data_lambda) <= 180) & (np.array(data_theta) > 90) & (
                np.array(data_theta) <= 135) & (np.array(data_alg)==algorithm) )
        index_list = list([index1,index2,index3,index4,index5,index6,index7,index8,index9,index10,index11,index12])
        for i in range(len(index_list)):
            mean_value = (np.mean(np.array(data_res)[index_list[i]]))
            print(' &', "%.3e"%mean_value ,end='')
        print('\\\ \n  & std',end='')
        for i in range(len(index_list)):
            std_valule = np.std(np.array(data_res)[index_list[i]],ddof=1)
            print(' &',"%.3e"%std_valule ,end='')
        print('\\\ ')

    for algorithm in alg:
        if algorithm=='TMOEA/D-DP':
            continue
        index1 = np.where((np.array(data_lambda) >0)  &(np.array(data_lambda) <= 45) & (np.array(data_theta) >0) & (
                np.array(data_theta) <= 45)  & ((np.array(data_alg)=='TMOEA/D-DP') | (np.array(data_alg)==algorithm)) )
        index2 = np.where((np.array(data_lambda) > 0) & (np.array(data_lambda) <= 45) & (np.array(data_theta) > 45) & (
                    np.array(data_theta) <= 90)  & ((np.array(data_alg)=='TMOEA/D-DP') | (np.array(data_alg)==algorithm)) )
        index3 = np.where((np.array(data_lambda) > 0) & (np.array(data_lambda) <= 45) & (np.array(data_theta) > 90) & (
                    np.array(data_theta) <= 135)  & ((np.array(data_alg)=='TMOEA/D-DP') | (np.array(data_alg)==algorithm)) )
        index4 = np.where((np.array(data_lambda) > 45) & (np.array(data_lambda) <= 90) & (np.array(data_theta) > 0) & (
                    np.array(data_theta) <= 45)  & ((np.array(data_alg)=='TMOEA/D-DP') | (np.array(data_alg)==algorithm)) )
        index5 = np.where((np.array(data_lambda) > 45) & (np.array(data_lambda) <= 90) & (np.array(data_theta) > 45) & (
                    np.array(data_theta) <= 90)  & ((np.array(data_alg)=='TMOEA/D-DP') | (np.array(data_alg)==algorithm)) )
        index6 = np.where((np.array(data_lambda) > 45) & (np.array(data_lambda) <= 90) & (np.array(data_theta) > 90) & (
                    np.array(data_theta) <= 135)  & ((np.array(data_alg)=='TMOEA/D-DP') | (np.array(data_alg)==algorithm)) )
        index7 = np.where((np.array(data_lambda) > 90) & (np.array(data_lambda) <= 135) & (np.array(data_theta) > 0) & (
                    np.array(data_theta) <= 45)  & ((np.array(data_alg)=='TMOEA/D-DP') | (np.array(data_alg)==algorithm)) )
        index8  = np.where((np.array(data_lambda) > 90) & (np.array(data_lambda) <= 135) & (np.array(data_theta) > 45) & (
                    np.array(data_theta) <= 90)  & ((np.array(data_alg)=='TMOEA/D-DP') | (np.array(data_alg)==algorithm)) )
        index9 =np.where((np.array(data_lambda) > 90) & (np.array(data_lambda) <= 135) & (np.array(data_theta) > 90) & (
                    np.array(data_theta) <= 135)  & ( (np.array(data_alg)=='TMOEA/D-DP') | (np.array(data_alg)==algorithm) ) )
        index10 = np.where((np.array(data_lambda) > 135) & (np.array(data_lambda) <= 180) & (np.array(data_theta) > 0) & (
                np.array(data_theta) <= 45)  & ((np.array(data_alg)=='TMOEA/D-DP') | (np.array(data_alg)==algorithm)) )
        index11 = np.where((np.array(data_lambda) > 135) & (np.array(data_lambda) <= 180) & (np.array(data_theta) > 45) & (
                np.array(data_theta) <= 90)  & ((np.array(data_alg)=='TMOEA/D-DP') | (np.array(data_alg)==algorithm)) )
        index12 = np.where((np.array(data_lambda) > 135) & (np.array(data_lambda) <= 180) & (np.array(data_theta) > 90) & (
                np.array(data_theta) <= 135)  & ( (np.array(data_alg)=='TMOEA/D-DP') | (np.array(data_alg)==algorithm) ))
        index_list = list([index1,index2,index3,index4,index5,index6,index7,index8,index9,index10,index11,index12])
        i = 0

        # Significance test
        for index in index_list:
            i = i+1
            import scipy.io as sio
            save_fn = 'D:\\matblab\\Function\\'+algorithm+str(i)+'.mat'
            sio.savemat(save_fn, {'res':np.array(data_res)[index],'alg': np.array(data_alg)[index],'theta': np.array(data_theta)[index],
                                  'R': np.array(data_R)[index],'lambda': np.array(data_lambda)[index],'index': np.array(data_count)[index]})


    fig1,ax1 = plt.subplots(1,1,figsize=(3,3))
    fig2,ax2 = plt.subplots(1,1,figsize=(3,3))
    for algorithm in alg:
        X = np.array(['(0,45]', '(45,90]', '(90,135]', '(135,180]'])
        Y = list()
        X_range = list()
        X_alg = list()
        index1 = np.where((np.array(data_lambda) > 0) & (np.array(data_lambda) <= 45) & (np.array(data_theta) > 0) & (
                np.array(data_theta) <= 45) & (
                              (np.array(data_alg) == algorithm)))
        index2 = np.where((np.array(data_lambda) > 45) & (np.array(data_lambda) <= 90) & (np.array(data_theta) > 0) & (
                np.array(data_theta) <= 45) & (
                              (np.array(data_alg) == algorithm)))
        index3 = np.where((np.array(data_lambda) > 90) & (np.array(data_lambda) <= 135) & (np.array(data_theta) > 0) & (
                np.array(data_theta) <= 45) & (
                              (np.array(data_alg) == algorithm)))
        index4 = np.where(
            (np.array(data_lambda) > 135) & (np.array(data_lambda) <= 180) & (np.array(data_theta) > 0) & (
                    np.array(data_theta) <= 45) & (
                (np.array(data_alg) == algorithm)))
        Y.append(np.array(data_res)[index1])
        Y.append(np.array(data_res)[index2])
        Y.append(np.array(data_res)[index3])
        Y.append(np.array(data_res)[index4])

        X_range.append(X[0])
        X_range.append(X[1])
        X_range.append(X[2])
        X_range.append(X[3])

        X_alg.append(algorithm)
        X_alg.append(algorithm)
        X_alg.append(algorithm)
        X_alg.append(algorithm)

        scale_ls = range(1, len(X) + 1)
        mean_values = list()
        mean_values.append(np.mean(Y[0]))
        mean_values.append(np.mean(Y[1]))
        mean_values.append(np.mean(Y[2]))
        mean_values.append(np.mean(Y[3]))
        ax1.set_xticks(scale_ls)
        ax1.set_xticklabels(X)
        ax1.plot(scale_ls, np.array(mean_values), marker=gv.mark.get(algorithm), color=gv.color.get(algorithm),
                 label=algorithm)

    for algorithm in alg:
        X = np.array(['(0,45]', '(45,90]', '(90,135]'])
        Y = list()
        X_range = list()
        X_alg = list()
        index1 = np.where((np.array(data_lambda) > 90) & (np.array(data_lambda) <= 135) & (np.array(data_theta) > 0) & (
                np.array(data_theta) <= 45) & (
                              (np.array(data_alg) == algorithm)))
        index2 = np.where(
            (np.array(data_lambda) > 90) & (np.array(data_lambda) <= 135) & (np.array(data_theta) > 45) & (
                    np.array(data_theta) <= 90) & (
                (np.array(data_alg) == algorithm)))
        index3 = np.where(
            (np.array(data_lambda) > 90) & (np.array(data_lambda) <= 135) & (np.array(data_theta) > 90) & (
                    np.array(data_theta) <= 135) & (
                (np.array(data_alg) == algorithm)))
        Y.append(np.array(data_res)[index1])
        Y.append(np.array(data_res)[index2])
        Y.append(np.array(data_res)[index3])

        X_range.append(X[0])
        X_range.append(X[1])
        X_range.append(X[2])

        X_alg.append(algorithm)
        X_alg.append(algorithm)
        X_alg.append(algorithm)

        scale_ls = range(1, len(X) + 1)
        mean_values = list()
        mean_values.append(np.mean(Y[0]))
        mean_values.append(np.mean(Y[1]))
        mean_values.append(np.mean(Y[2]))
        ax2.set_xticks(scale_ls)
        ax2.set_xticklabels(X)
        ax2.plot(scale_ls, np.array(mean_values), marker=gv.mark.get(algorithm), color=gv.color.get(algorithm),
                        label=algorithm)

    ax1.set_xlabel(r'$\lambda$', gv.font2)
    ax1.set_ylabel(r'$I_H$', gv.font2)
    ax2.set_xlabel(r'$\theta$', gv.font2)
    ax2.set_ylabel(r'$I_H$', gv.font2)
    plt.ylim([0.2, 0.72])

    fig1.savefig('./AC_new_lambda.pdf',bbox_inches = 'tight')

    fig2.savefig('./AC_new_theta.pdf',bbox_inches = 'tight')

    handles, labels = ax1.get_legend_handles_labels()
    fig3,ax3 = plt.subplots(1,1,figsize=(5,0.8))
    ax3.axis('off')
    fig3.legend(handles, labels, bbox_to_anchor=[1.02, 1.15], ncol=2, fontsize='xx-large')
    fig3.savefig('./AC_new_label.pdf',bbox_inches = 'tight')
    fig3.show()
    fig1.show()
