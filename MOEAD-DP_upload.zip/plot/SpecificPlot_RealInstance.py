import pickle

from matplotlib.pyplot import savefig

import GlobalValues as gv
import numpy as np
import HyperVolume as ea
from matplotlib import pyplot as plt
def median(a):
    b = np.argsort(a)
    return b[int(len(b)/2)]
if __name__ == "__main__":
    sample_size = 121
    stepLength = 199
    T = 6
    maxGeneration = 200
    read_Dir = '../ANOVA/'
    read_Dir2 = ''
    Dir = '../ANOVA/'
    Dir2 = 'plot/'
    maxrun = 10
    width = 8.5
    height = 8.5
    fig,axes = plt.subplots(3,2,figsize=(width,height),gridspec_kw={'height_ratios': [0.1,8,8]})
    ax_00 = axes[0, 0]
    ax_01 = axes[0, 1]
    ax_00.axis('off')
    ax_01.axis('off')
    ax1 = axes[1, 0]
    ax2 = axes[1, 1]
    ax3 = axes[2, 0]
    ax4 = axes[2, 1]
    axs = [ax1,ax2,ax3,ax4]
    samples = [902,904,906,908]
    # samples = [700, 832, 834, 908]
    med  = np.array([[8,8,10],[10,10,5],[8,8,1],[6,6,2]])
    # med  = np.array([[9,9,10],[7,7,3],[1,1,9],[4,4,6]])
    # med = np.array([[4, 4, 6], [1, 1, 9], [7, 7, 3], [1, 1, 6]])
    for i in range(4):
        count = samples[i]
        # HV_list = list()
        # for run in range(1,maxrun+1):
        #     f = open('./' + read_Dir + read_Dir2 + 'DPS_' + str(count) + '_' + str(run) + ".txt", 'rb')
        #     ([res_ind_DPS, res_f_DPS, res_DPS, Mu, gv.Lambda, gv.R, gv.Thet]) = pickle.load(f)
        #     f.close()
        #     HV_list.append(ea.indicator.HV(res_DPS,gv.rf))
        # median_run = median(HV_list)+1
        median_run = med[i][0]
        f = open('./' + read_Dir + read_Dir2 + 'DPS_' + str(count) + '_' + str(median_run) + ".txt",'rb')
        print('第',str(median_run),'次run:\n')
        ([res_ind_DPS, res_f_DPS, res_DPS, Mu, gv.Lambda, gv.R, gv.Thet]) = pickle.load(f)
        f.close()
        N = len(Mu)


        # read file
        #
        # f = open('./AC/'+str(Dir)+'dp_' + str(count) + ".txt", 'rb')
        # [Mu, gv.Lambda, gv.R, gv.Thet, res_DPS]= pickle.load(f)
        # plt_DPS = axs[i].scatter(res_DPS[:, 1], res_DPS[:, 0], marker="o", color='white', edgecolor='r',label='MOEAD-DP')
        # f.close()
        #
        f = open('./AC/'+str(Dir)+'FSF_dp_' + str(count) + ".txt", 'rb')
        ([Mu, gv.Lambda, gv.R, gv.Thet, res_FSF_dp]) = pickle.load(f)
        r = ea.ndsortTNS(res_FSF_dp, 1)[0]
        index = np.where(r == 1)[0]
        res_FSF_dp = res_FSF_dp[index]
        f.close()

        f = open('./AC/'+str(Dir)+'FSF_SFS' + str(count) + ".txt", 'rb')
        ([Mu, gv.Lambda, gv.R, gv.Thet, res_FSF_SFS]) = pickle.load(f)
        r = ea.ndsortTNS(res_FSF_SFS, 1)[0]
        index = np.where(r == 1)[0]
        res_FSF_SFS = res_FSF_SFS[index]
        f.close()

        f = open('./AC/'+str(Dir)+'FSF_WFS' + str(count) + ".txt", 'rb')
        ([Mu, gv.Lambda, gv.R, gv.Thet, res_FSF_WFS]) = pickle.load(f)
        r = ea.ndsortTNS(res_FSF_WFS, 1)[0]
        index = np.where(r == 1)[0]
        res_FSF_WFS = res_FSF_WFS[index]
        f.close()

        median_run = med[i][1]
        f = open('./AC/' + str(Dir) + 'SFS_' + str(count)+"_"+str(median_run) + ".txt", 'rb')
        ([Mu, gv.Lambda, gv.R, gv.Thet, res_SFS,_]) = pickle.load(f)
        r = ea.ndsortTNS(res_SFS, 1)[0]
        index = np.where(r == 1)[0]
        res_SFS = res_SFS[index]
        f.close()
        median_run = med[i][2]
        f = open('./AC/' + str(Dir) + 'WFS_' + str(count)+"_"+str(median_run) + ".txt", 'rb')
        ([Mu, gv.Lambda, gv.R, gv.Thet, res_WFS,_]) = pickle.load(f)
        r = ea.ndsortTNS(res_WFS, 1)[0]
        index = np.where(r == 1)[0]
        res_WFS = res_WFS[index]
        f.close()

        N = len(Mu)
        axs[i].scatter(res_DPS[:, 1], res_DPS[:, 0], marker=gv.mark['TMOEA/D-DP'],color='white', edgecolor=gv.color['TMOEA/D-DP'],label='TMOEA/D-DP')
        axs[i].scatter(res_SFS [:, 1], res_SFS[:, 0], marker=gv.mark['MOEA/D-SF'],color=gv.color['MOEA/D-SF'],label='MOEA/D-SFS')
        axs[i].scatter(res_WFS[:, 1], res_WFS[:, 0], marker=gv.mark['MOEA/D-WF'],color=gv.color['MOEA/D-WF'],label='MOEA/D-WFS')
        axs[i].scatter(res_FSF_dp[:, 1], res_FSF_dp[:, 0], marker=gv.mark['FSF-DP'],color=gv.color['FSF-DP'],label='FSF-DP')
        axs[i].scatter(res_FSF_SFS[:, 1], res_FSF_SFS[:, 0],marker=gv.mark['FSF-SF'],color=gv.color['FSF-SF'],label='FSF-SF')
        axs[i].scatter(res_FSF_WFS[:, 1], res_FSF_WFS[:, 0], marker=gv.mark['FSF-WF'],color=gv.color['FSF-WF'],label='FSF-WF')
        axs[i].set_title(r'$\lambda$=' + str(gv.Lambda), gv.font2)

        axs[i].set_xlabel('Power Consumption',gv.font2)
        axs[i].set_ylabel('Number of Requests',gv.font2)

    handles, labels = ax1.get_legend_handles_labels()
    fig.legend(handles, labels,bbox_to_anchor=[0.95, 1.01],ncol=3,fontsize='xx-large')
    plt.show()


    Dir = '../MC/ANOVA/'
    Dir2 = ''
    maxrun = 10
    width =8
    height =8
    fig,axes = plt.subplots(2,2,figsize=(width,height),)

    ax1 = axes[0, 0]
    ax2 = axes[0, 1]
    ax3 = axes[1, 0]
    ax4 = axes[1, 1]
    axs = [ax1,ax2,ax3,ax4]
    samples = [700, 832, 834, 908]
    med  = np.array([[9,6,10],[8,2,5],[10,10,1],[4,4,9]])
    for i in range(4):
        count = samples[i]
        median_run_DPS = med[i,0]
        median_run_BETP = med[i,1]
        median_run_MOEAD_BETP = med[i,2]
        f = open(Dir + Dir2 + '/plt_' + str(count) + '_' + str(median_run_DPS) + ".txt", 'rb')
        ([res_compare_DPS, _,_, Mu, gv.Lambda, gv.R, gv.Thet]) = pickle.load(f)
        f.close()

        f = open(Dir + Dir2 + '/plt_' + str(count) + '_' + str(median_run_BETP) + ".txt", 'rb')
        ([_, res_compare_BETP,_, Mu, gv.Lambda, gv.R, gv.Thet]) = pickle.load(f)
        f.close()

        f = open(Dir + Dir2 + '/plt_' + str(count) + '_' + str(median_run_BETP) + ".txt", 'rb')
        ([_,_, res_compare_MOEAD_BETP, Mu, gv.Lambda, gv.R, gv.Thet]) = pickle.load(f)
        f.close()
        r_BETP = ea.ndsortTNS(res_compare_BETP, 1)[0]
        index_BETP = np.where(r_BETP == 1)[0]
        result_BETP = res_compare_BETP[index_BETP]
        r_DPS = ea.ndsortTNS(res_compare_DPS, 1)[0]
        index_DPS = np.where(r_DPS == 1)[0]
        result_DPS = res_compare_DPS[index_DPS]
        r_MOEAD_BETP = ea.ndsortTNS(res_compare_MOEAD_BETP, 1)[0]
        index_MOEAD_BETP = np.where(r_MOEAD_BETP == 1)[0]
        result_MOEAD_BETP = res_compare_MOEAD_BETP[index_MOEAD_BETP]
        N = len(Mu)
        axs[i].scatter(result_DPS[:, 0], result_DPS[:, 1], marker=gv.mark['TMOEA/D-DP'],color='white', edgecolor=gv.color['TMOEA/D-DP'],label='TMOEA/D-DP'+'($\mathcal{M}_\mathcal{A}$)')
        axs[i].scatter(result_BETP[0, 0], result_BETP[0, 1], marker=gv.mark['BETP'],color=gv.color['BETP'],label='BETP'+'($\mathcal{M}_\mathcal{B}$)')
        axs[i].scatter(result_MOEAD_BETP[:, 0], result_MOEAD_BETP[:, 1], marker=gv.mark['MOEA/D-BETP'],color=gv.color['MOEA/D-BETP'],label='MOEA/D-BETP'+'($\mathcal{M}_\mathcal{B}$)')

        axs[i].set_xlabel('Power Consumption',gv.font2)
        axs[i].set_ylabel('Number of Requests',gv.font2)

        nadir_x_1 = result_BETP[0, 0]
        nadir_y_1 = result_BETP[0, 1]
        for j in range(len(result_MOEAD_BETP)):
            if result_MOEAD_BETP[j][0] < nadir_x_1:
                nadir_x_1 = result_MOEAD_BETP[j][0]
            if result_MOEAD_BETP[j][1] < nadir_y_1:
                nadir_y_1 = result_MOEAD_BETP[j][1]
        index_temp = np.where((result_DPS[:,0]<=nadir_x_1) & (result_DPS[:,1]<=nadir_y_1))
        nadir_x_2 = 1
        nadir_y_2 = 1
        for r1,r2 in result_DPS[index_temp]:
            if r1 < nadir_x_2:
                nadir_x_2 = r1
            if r2 < nadir_y_2:
                nadir_y_2 = r2
        nadir_y_2 = nadir_y_2 - 0.011
        nadir_x_2 = nadir_x_2 - 0.011
        axs[i].plot([nadir_x_1, nadir_x_2], [nadir_y_1, nadir_y_1], c='b', linestyle='--')
        axs[i].plot([nadir_x_1, nadir_x_2], [nadir_y_2, nadir_y_2], c='b', linestyle='--')
        axs[i].plot([nadir_x_1, nadir_x_1], [nadir_y_1, nadir_y_2], c='b', linestyle='--')
        axs[i].plot([nadir_x_2, nadir_x_2], [nadir_y_1, nadir_y_2], c='b', linestyle='--')
        axs[i].set_title(r'$\lambda$='+str(gv.Lambda),gv.font2)

    handles, labels = ax1.get_legend_handles_labels()
    ax1.legend(fontsize='large')
    ax2.legend(fontsize='large')
    ax3.legend(fontsize='large')
    ax4.legend(fontsize='large',bbox_to_anchor=(0.195,0.8))
    fig.show()
