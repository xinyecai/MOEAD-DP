import pickle

from matplotlib.pyplot import savefig

import GlobalValues as gv
import numpy as np
import geatpy as ea
from matplotlib import pyplot as plt
def median(a):
    b = np.argsort(a)
    return b[int(len(b)/2)]
if __name__ == "__main__":
    # Performance of four algorithms on the environment model in terms of the mean $I_H$ values
    stepLength = 199
    T = 6
    maxGeneration = 200
    read_Dir = '../ANOVA/'
    read_Dir2 = ''
    Dir = '../MC/ANOVA/'
    # Dir2 = 'plot/'
    Dir2 = 'plot/'
    maxrun = 10
    # gv.Lambda = -5
    data_lambda=list()
    data_theta = list()
    data_R = list()
    data_res = list()
    data_alg = list()
    alg=np.array(['TMOEA/D-DP','MOEA/D-BETP'])

    for count in range(700,836):
        HV_list_DPS = list()
        HV_list_BETP = list()
        for run in range(1, maxrun + 1):
            f = open('./' + Dir + 'plt_' + str(count) + '_' + str(run)+ ".txt", 'rb')
            ([res_compare_DPS, _,res_compare_BETP, Mu, gv.Lambda, gv.R, gv.Thet]) = pickle.load(f)
            f.close()

            r_BETP = ea.ndsortTNS(res_compare_BETP, 1)[0]
            index_BETP = np.where(r_BETP == 1)[0]
            result_BETP = res_compare_BETP[index_BETP]

            r_DPS = ea.ndsortTNS(res_compare_DPS, 1)[0]
            index_DPS = np.where(r_DPS == 1)[0]
            result_DPS = res_compare_DPS[index_DPS]

            HV_list_DPS.append(ea.indicator.HV(result_DPS, gv.rf))
            HV_list_BETP.append(ea.indicator.HV(result_BETP, gv.rf))
        median_run_DPS = median(HV_list_DPS)
        median_run_BETP = median(HV_list_BETP)
        data_res.append(HV_list_DPS[median_run_DPS])
        data_lambda.append(gv.Lambda)
        data_theta.append(gv.Thet)
        data_R.append(gv.R)
        data_alg.append('TMOEA/D-DP')

        data_res.append(HV_list_BETP[median_run_BETP])
        data_lambda.append(gv.Lambda)
        data_theta.append(gv.Thet)
        data_R.append(gv.R)
        data_alg.append('MOEA/D-BETP')

    for algorithm in alg:
        print('\n \multirow{2}[0]{*}{',algorithm,'} & mean  ',end='')
        index1 = np.where((np.array(data_lambda) >0)  &(np.array(data_lambda) <= 45) & (np.array(data_theta) >0) & (
                np.array(data_theta) <= 45) & (np.array(data_alg)==algorithm))
        index2 = np.where((np.array(data_lambda) > 0) & (np.array(data_lambda) <= 45) & (np.array(data_theta) > 45) & (
                    np.array(data_theta) <= 90) & (np.array(data_alg)==algorithm) )
        index3 = np.where((np.array(data_lambda) > 0) & (np.array(data_lambda) <= 45) & (np.array(data_theta) > 90) & (
                    np.array(data_theta) <= 135) & (np.array(data_alg)==algorithm) )
        index4 = np.where((np.array(data_lambda) > 45) & (np.array(data_lambda) <= 90) & (np.array(data_theta) > 0) & (
                    np.array(data_theta) <= 45) & (np.array(data_alg)==algorithm) )
        index5 = np.where((np.array(data_lambda) > 45) & (np.array(data_lambda) <= 90) & (np.array(data_theta) > 45) & (
                    np.array(data_theta) <= 90) & (np.array(data_alg)==algorithm) )
        index6 = np.where((np.array(data_lambda) > 45) & (np.array(data_lambda) <= 90) & (np.array(data_theta) > 90) & (
                    np.array(data_theta) <= 135) & (np.array(data_alg)==algorithm) )
        index7 = np.where((np.array(data_lambda) > 90) & (np.array(data_lambda) <= 135) & (np.array(data_theta) > 0) & (
                    np.array(data_theta) <= 45) & (np.array(data_alg)==algorithm) )
        index8  = np.where((np.array(data_lambda) > 90) & (np.array(data_lambda) <= 135) & (np.array(data_theta) > 45) & (
                    np.array(data_theta) <= 90) & (np.array(data_alg)==algorithm) )
        index9 =np.where((np.array(data_lambda) > 90) & (np.array(data_lambda) <= 135) & (np.array(data_theta) > 90) & (
                    np.array(data_theta) <= 135) & (np.array(data_alg)==algorithm) )
        index10 = np.where((np.array(data_lambda) > 135) & (np.array(data_lambda) <= 180) & (np.array(data_theta) > 0) & (
                np.array(data_theta) <= 45) & (np.array(data_alg)==algorithm) )
        index11 = np.where((np.array(data_lambda) > 135) & (np.array(data_lambda) <= 180) & (np.array(data_theta) > 45) & (
                np.array(data_theta) <= 90) & (np.array(data_alg)==algorithm) )
        index12 = np.where((np.array(data_lambda) > 135) & (np.array(data_lambda) <= 180) & (np.array(data_theta) > 90) & (
                np.array(data_theta) <= 135) & (np.array(data_alg)==algorithm) )
        index_list = list([index1,index2,index3,index4,index5,index6,index7,index8,index9,index10,index11,index12])
        for i in range(len(index_list)):
            mean_value = (np.mean(np.array(data_res)[index_list[i]]))
            print(' &', "\\textbf{%.3e}"%mean_value ,end='')
        print('\\\ \n  & std',end='')
        for i in range(len(index_list)):
            std_valule = np.std(np.array(data_res)[index_list[i]],ddof=1)
            print(' &',"%.3e"%std_valule ,end='')
        print('\\\ ')

    for algorithm in alg:
        if algorithm=='TMOEA/D-DP':
            continue
        index1 = np.where((np.array(data_lambda) >0)  &(np.array(data_lambda) <= 45) & (np.array(data_theta) >0) & (
                np.array(data_theta) <= 45)  & ((np.array(data_alg)=='TMOEA/D-DP') | (np.array(data_alg)==algorithm)) )
        index2 = np.where((np.array(data_lambda) > 0) & (np.array(data_lambda) <= 45) & (np.array(data_theta) > 45) & (
                    np.array(data_theta) <= 90)  & ((np.array(data_alg)=='TMOEA/D-DP') | (np.array(data_alg)==algorithm)) )
        index3 = np.where((np.array(data_lambda) > 0) & (np.array(data_lambda) <= 45) & (np.array(data_theta) > 90) & (
                    np.array(data_theta) <= 135)  & ((np.array(data_alg)=='TMOEA/D-DP') | (np.array(data_alg)==algorithm)) )
        index4 = np.where((np.array(data_lambda) > 45) & (np.array(data_lambda) <= 90) & (np.array(data_theta) > 0) & (
                    np.array(data_theta) <= 45)  & ((np.array(data_alg)=='TMOEA/D-DP') | (np.array(data_alg)==algorithm)) )
        index5 = np.where((np.array(data_lambda) > 45) & (np.array(data_lambda) <= 90) & (np.array(data_theta) > 45) & (
                    np.array(data_theta) <= 90)  & ((np.array(data_alg)=='TMOEA/D-DP') | (np.array(data_alg)==algorithm)) )
        index6 = np.where((np.array(data_lambda) > 45) & (np.array(data_lambda) <= 90) & (np.array(data_theta) > 90) & (
                    np.array(data_theta) <= 135)  & ((np.array(data_alg)=='TMOEA/D-DP') | (np.array(data_alg)==algorithm)) )
        index7 = np.where((np.array(data_lambda) > 90) & (np.array(data_lambda) <= 135) & (np.array(data_theta) > 0) & (
                    np.array(data_theta) <= 45)  & ((np.array(data_alg)=='TMOEA/D-DP') | (np.array(data_alg)==algorithm)) )
        index8  = np.where((np.array(data_lambda) > 90) & (np.array(data_lambda) <= 135) & (np.array(data_theta) > 45) & (
                    np.array(data_theta) <= 90)  & ((np.array(data_alg)=='TMOEA/D-DP') | (np.array(data_alg)==algorithm)) )
        index9 =np.where((np.array(data_lambda) > 90) & (np.array(data_lambda) <= 135) & (np.array(data_theta) > 90) & (
                    np.array(data_theta) <= 135)  & ( (np.array(data_alg)=='TMOEA/D-DP') | (np.array(data_alg)==algorithm) ) )
        index10 = np.where((np.array(data_lambda) > 135) & (np.array(data_lambda) <= 180) & (np.array(data_theta) > 0) & (
                np.array(data_theta) <= 45)  & ((np.array(data_alg)=='TMOEA/D-DP') | (np.array(data_alg)==algorithm)) )
        index11 = np.where((np.array(data_lambda) > 135) & (np.array(data_lambda) <= 180) & (np.array(data_theta) > 45) & (
                np.array(data_theta) <= 90)  & ((np.array(data_alg)=='TMOEA/D-DP') | (np.array(data_alg)==algorithm)) )
        index12 = np.where((np.array(data_lambda) > 135) & (np.array(data_lambda) <= 180) & (np.array(data_theta) > 90) & (
                np.array(data_theta) <= 135)  & ( (np.array(data_alg)=='TMOEA/D-DP') | (np.array(data_alg)==algorithm) ))
        index_list = list([index1,index2,index3,index4,index5,index6,index7,index8,index9,index10,index11,index12])
        i = 0
        for index in index_list:
            i = i+1
            # index = np.where( (np.array(data_theta) <=45) & (np.array(data_lambda)>135) & (np.array(data_lambda)<=180)  & ((np.array(data_alg)=='MOEA/D-DP') | (np.array(data_alg)=='MOEA/D-SF'))       )
            import scipy.io as sio
            save_fn = 'D:\\matblab\\云计算调度代码\\Function\\MC_MOEAD-BETP'+str(i)+'.mat'
            sio.savemat(save_fn, {'res':np.array(data_res)[index],'alg': np.array(data_alg)[index],'theta': np.array(data_theta)[index],
                                  'R': np.array(data_R)[index],'lambda': np.array(data_lambda)[index]})



    # index = np.where( (np.array(data_theta) <=30) & (np.array(data_lambda)>=100) & (np.array(data_lambda)<150))
    # import scipy.io as sio
    # save_fn = 'D:\\matblab\\云计算调度代码\\Function\\2.mat'
    # sio.savemat(save_fn, {'res':(np.array(data_res)[index]),'alg': (np.array(data_alg)[index])})  # 和上面的一样，存在了array变量的第一行



    fig1,ax1 = plt.subplots(1,1,figsize=(4.3,4.3))
    fig2,ax2 = plt.subplots(1,1,figsize=(4.3,4.3))
    for algorithm in alg:
        X = np.array(['(0,45]', '(45,90]', '(90,135]', '(135,180]'])
        Y = list()
        X_range = list()
        X_alg = list()
        index1 = np.where( (np.array(data_lambda) >0)  &(np.array(data_lambda) <= 45) & (np.array(data_theta) > 0) & (
                    np.array(data_theta) <= 45) & (
                         (np.array(data_alg) == algorithm)))
        index2 = np.where( (np.array(data_lambda) >45)  &(np.array(data_lambda) <= 90) & (np.array(data_theta) > 0) & (
                    np.array(data_theta) <= 45) & (
                         (np.array(data_alg) == algorithm)))
        index3 = np.where( (np.array(data_lambda) >90)  &(np.array(data_lambda) <= 135) &  (np.array(data_theta) > 0) & (
                    np.array(data_theta) <= 45) & (
                        (np.array(data_alg) == algorithm)))
        index4 = np.where( (np.array(data_lambda) >135)  &(np.array(data_lambda) <= 180) &  (np.array(data_theta) > 0) & (
                    np.array(data_theta) <= 45) & (
                        (np.array(data_alg) == algorithm)))
        Y.append(np.array(data_res)[index1])
        Y.append(np.array(data_res)[index2])
        Y.append(np.array(data_res)[index3])
        Y.append(np.array(data_res)[index4])

        X_range.append(X[0])
        X_range.append(X[1])
        X_range.append(X[2])
        X_range.append(X[3])

        X_alg.append(algorithm)
        X_alg.append(algorithm)
        X_alg.append(algorithm)
        X_alg.append(algorithm)

        scale_ls = range(1,len(X)+1)
        mean_values = list()
        mean_values.append(np.mean(Y[0]))
        mean_values.append(np.mean(Y[1]))
        mean_values.append(np.mean(Y[2]))
        mean_values.append(np.mean(Y[3]))
        ax1.set_xticks(scale_ls)
        ax1.set_xticklabels(X)
        ax1.plot(scale_ls, np.array(mean_values), marker=gv.mark.get(algorithm), color=gv.color.get(algorithm), label=algorithm)
    for algorithm in alg:
        X = np.array(['(0,45]', '(45,90]', '(90,135]'])
        Y = list()
        X_range = list()
        X_alg = list()
        index1 = np.where( (np.array(data_lambda) >90)  &(np.array(data_lambda) <= 135) & (np.array(data_theta) > 0) & (
                    np.array(data_theta) <= 45) & (
                         (np.array(data_alg) == algorithm)))
        index2 = np.where( (np.array(data_lambda) >90)  &(np.array(data_lambda) <= 135) & (np.array(data_theta) > 45) & (
                    np.array(data_theta) <= 90) & (
                         (np.array(data_alg) == algorithm)))
        index3 = np.where( (np.array(data_lambda) >90)  &(np.array(data_lambda) <= 135) &  (np.array(data_theta) > 90) & (
                    np.array(data_theta) <= 135) & (
                        (np.array(data_alg) == algorithm)))
        Y.append(np.array(data_res)[index1])
        Y.append(np.array(data_res)[index2])
        Y.append(np.array(data_res)[index3])

        X_range.append(X[0])
        X_range.append(X[1])
        X_range.append(X[2])

        X_alg.append(algorithm)
        X_alg.append(algorithm)
        X_alg.append(algorithm)

        scale_ls = range(1,len(X)+1)
        mean_values = list()
        mean_values.append(np.mean(Y[0]))
        mean_values.append(np.mean(Y[1]))
        mean_values.append(np.mean(Y[2]))
        ax2.set_xticks(scale_ls)
        ax2.set_xticklabels(X)
        if algorithm=='TMOEA/D-DP':
            label_name = algorithm+'($\mathcal{M}_\mathcal{A}$)'
        else:
            label_name = algorithm + '($\mathcal{M}_\mathcal{B}$)'
        ax2.plot(scale_ls, np.array(mean_values), marker=gv.mark.get(algorithm), color=gv.color.get(algorithm), label=label_name)
        # ax3.plot([], [], marker=gv.mark.get(algorithm), color=gv.color.get(algorithm),
        #          label=algorithm)
    ax1.set_xlabel(r'$\lambda$', gv.font2)
    ax1.set_ylabel(r'$I_H$', gv.font2)
    ax2.set_xlabel(r'$\theta$', gv.font2)
    ax2.set_ylabel(r'$I_H$', gv.font2)
    plt.ylim([0.15, 0.6])
    ax1.legend(fontsize='x-large', loc='upper right')
    ax2.legend(fontsize='x-large', loc='upper right')


    # fig1.savefig('D:\\texstudio\workplace\CloudServer\\figure\MC_new_lambda.pdf',bbox_inches = 'tight')
    # fig2.savefig('D:\\texstudio\workplace\CloudServer\\figure\MC_new_theta.pdf',bbox_inches = 'tight')

    fig1.show()
    fig2.show()

    #
    # fig,[ax1,ax2] = plt.subplots(1,2,sharey=True,figsize=(8.6,4.3))
    # # fig.tight_layout()
    # fig.subplots_adjust(wspace =0.6, hspace =0,bottom=-2,top=1,left=-2,right=1)
    # # fig1,ax1=plt.subplots(1,1,figsize=(5,5))
    # # fig2,ax2 = plt.subplots(1, 1, figsize=(5, 5))
    # for algorithm in alg:
    #     X = np.array(['(0,45]', '(45,90]', '(90,135]', '(135,180]'])
    #     Y = list()
    #     X_range = list()
    #     X_alg = list()
    #     index1 = np.where( (np.array(data_lambda) >0)  &(np.array(data_lambda) <= 45) & (np.array(data_theta) > 0) & (
    #                 np.array(data_theta) <= 45) & (
    #                      (np.array(data_alg) == algorithm)))
    #     index2 = np.where( (np.array(data_lambda) >45)  &(np.array(data_lambda) <= 90) & (np.array(data_theta) > 0) & (
    #                 np.array(data_theta) <= 45) & (
    #                      (np.array(data_alg) == algorithm)))
    #     index3 = np.where( (np.array(data_lambda) >90)  &(np.array(data_lambda) <= 135) &  (np.array(data_theta) > 0) & (
    #                 np.array(data_theta) <= 45) & (
    #                     (np.array(data_alg) == algorithm)))
    #     index4 = np.where( (np.array(data_lambda) >135)  &(np.array(data_lambda) <= 180) &  (np.array(data_theta) > 0) & (
    #                 np.array(data_theta) <= 45) & (
    #                     (np.array(data_alg) == algorithm)))
    #     Y.append(np.array(data_res)[index1])
    #     Y.append(np.array(data_res)[index2])
    #     Y.append(np.array(data_res)[index3])
    #     Y.append(np.array(data_res)[index4])
    #
    #     X_range.append(X[0])
    #     X_range.append(X[1])
    #     X_range.append(X[2])
    #     X_range.append(X[3])
    #
    #     X_alg.append(algorithm)
    #     X_alg.append(algorithm)
    #     X_alg.append(algorithm)
    #     X_alg.append(algorithm)
    #
    #     scale_ls = range(1,len(X)+1)
    #     mean_values = list()
    #     mean_values.append(np.mean(Y[0]))
    #     mean_values.append(np.mean(Y[1]))
    #     mean_values.append(np.mean(Y[2]))
    #     mean_values.append(np.mean(Y[3]))
    #     ax1.set_xticks(scale_ls)
    #     ax1.set_xticklabels(X)
    #     fig1 = ax1.plot(scale_ls, np.array(mean_values), marker=gv.mark.get(algorithm), color=gv.color.get(algorithm), label=algorithm)
    # for algorithm in alg:
    #     X = np.array(['(0,45]', '(45,90]', '(90,135]'])
    #     Y = list()
    #     X_range = list()
    #     X_alg = list()
    #     index1 = np.where( (np.array(data_lambda) >90)  &(np.array(data_lambda) <= 135) & (np.array(data_theta) > 0) & (
    #                 np.array(data_theta) <= 45) & (
    #                      (np.array(data_alg) == algorithm)))
    #     index2 = np.where( (np.array(data_lambda) >90)  &(np.array(data_lambda) <= 135) & (np.array(data_theta) > 45) & (
    #                 np.array(data_theta) <= 90) & (
    #                      (np.array(data_alg) == algorithm)))
    #     index3 = np.where( (np.array(data_lambda) >90)  &(np.array(data_lambda) <= 135) &  (np.array(data_theta) > 90) & (
    #                 np.array(data_theta) <= 135) & (
    #                     (np.array(data_alg) == algorithm)))
    #     Y.append(np.array(data_res)[index1])
    #     Y.append(np.array(data_res)[index2])
    #     Y.append(np.array(data_res)[index3])
    #
    #     X_range.append(X[0])
    #     X_range.append(X[1])
    #     X_range.append(X[2])
    #
    #     X_alg.append(algorithm)
    #     X_alg.append(algorithm)
    #     X_alg.append(algorithm)
    #
    #     scale_ls = range(1,len(X)+1)
    #     mean_values = list()
    #     mean_values.append(np.mean(Y[0]))
    #     mean_values.append(np.mean(Y[1]))
    #     mean_values.append(np.mean(Y[2]))
    #     ax2.set_xticks(scale_ls)
    #     ax2.set_xticklabels(X)
    #     if algorithm=='TMOEA/D-DP':
    #         label_name = algorithm+'($\mathcal{M}_\mathcal{A}$)'
    #     else:
    #         label_name = algorithm + '($\mathcal{M}_\mathcal{B}$)'
    #     fig2 = ax2.plot(scale_ls, np.array(mean_values), marker=gv.mark.get(algorithm), color=gv.color.get(algorithm), label=label_name)
    #     # ax3.plot([], [], marker=gv.mark.get(algorithm), color=gv.color.get(algorithm),
    #     #          label=algorithm)
    # ax1.set_xlabel(r'$\lambda$', gv.font2)
    # ax1.set_ylabel(r'$I_H$', gv.font2)
    # ax2.set_xlabel(r'$\theta$', gv.font2)
    # handles, labels = ax1.get_legend_handles_labels()
    #
    # # fig.legend(handles, labels,bbox_to_anchor=[0.8, 1.15],ncol=3,fontsize='x-large',bbox_transform = BlendedGenericTransform(fig.transFigure, ax1.transAxes))
    # # plt.legend(loc='center left', bbox_to_anchor=(0.031, 0.93),ncol=2,fontsize='x-large')
    # plt.legend(loc='upper right', fontsize='x-large')
    # # ax2.legend(fontsize='x-large', loc='BestOutside')
    # # ax3.legend(fontsize='x-large',loc='lower left')
    # # ax3.axis('off')
    # plt.show()
    #
    # if count>=900 and count<=910:
    #     fig.savefig('D:\\texstudio\workplace\CloudServer\\figure\MC_Real.pdf')
    # else:
    #     fig.savefig('D:\\texstudio\workplace\CloudServer\\figure\MC_new.pdf')