import csv
import time
import GlobalValues as gv
import numpy as np
def e(k,length):
    A = np.zeros(length)
    if k!=0:
        A[k-1] = 1
    return A

def Caculate_power(k,mu,type,mu_count=0):
    p=0
    if type == 1:
        p = gv.Pc + gv.a * (np.power(mu[k], gv.Alpha))
    else:
        if type==2:
            p = gv.Pc+gv.a * (np.power(mu[k],gv.Alpha))
        else:
            p = gv.Pc
    return p

def Caculate_cx(state,n,Mu):
    WNr = np.sum(state) / (n + gv.R)
    mu_count = 0
    for k in range(n):
        mu_count = mu_count + Caculate_power(k,Mu,2,mu_count)
    power = 0
    for k in range(state[2]):
        power=power+Caculate_power(k,Mu,2,mu_count)
    for k in range(state[1]):
        power = power + Caculate_power(k+state[2], Mu, 1,mu_count)

    power = power + (n - state[2] - state[1]) * gv.Pc #cold

    power = power / mu_count
    return WNr, power
def check(v,N):
    file = open('./222.csv', 'w', newline='')
    writer = csv.writer(file)
    temp_table = -np.ones((gv.R+1,N+1,N+1))
    target = gv.target
    for q in range(0, gv.R-1):
        for i in range(0, N):
            for j in range(0, N - i):
                current_state = np.array([q, i, j])
                # state_location = int(q * (N + 2) * (N + 1) / 2 + i * (2 * N + 3 - i) / 2 + j)
                state_location1 = int((gv.R+((q + 1-gv.R)<=0)*(q+1-gv.R)) * (N + 2) * (N + 1) / 2 + (i) * (2 * N + 3 - (i)) / 2 + j)
                state_location2 = int((gv.R+((q + 2-gv.R)<=0)*(q+2-gv.R)) * (N + 2) * (N + 1) / 2 + (i) * (2 * N + 3 - (i)) / 2 + j)
                state_location3 = int((q + 0) * (N + 2) * (N + 1) / 2 + (N-j+((i+1-N+j)<=0)*(i+1-N+j)) * (2 * N + 3 - (N-j+((i+1-N+j)<=0)*(i+1-N+j)) ) / 2 + j)
                state_location4 = int((gv.R+((q + 1-gv.R)<=0)*(q+1-gv.R)) * (N + 2) * (N + 1) / 2 + (N-j+((i+1-N+j)<=0)*(i+1-N+j)) * (2 * N + 3 - (N-j+((i+1-N+j)<=0)*(i+1-N+j))) / 2 + j)
                
                temp_table[q,i,j] = (v[state_location1][target]-v[state_location2][target]-v[state_location3][target]+v[state_location4][target])
                # print(temp_table[q,i,j],'\n')
                # temp_table[q, i, j] = (temp_table[q,i,j]>1E-10)*temp_table[q, i, j]
                if temp_table[q,i,j]>0:
                    print('error:[',str(q),',',str(i),',',str(j),']=',str(temp_table[q,i,j]),'\n')
                # temp_table[q, i, j] = v[state_location1] - v[state_location2] - v[state_location3] + \
                #                       v[state_location4]
            writer.writerow(temp_table[q,i,:])
        writer.writerow('')
    file.close()

def SOLVE(A, B):
    v = np.linalg.solve(A, B)
    return v

def evaluation(N,Mu,f,weight):
    state_num =int((gv.R + 1) * (N + 2) * (N + 1) / 2)
    v = np.zeros((state_num + 1,3))

    A = np.zeros((state_num + 1, state_num + 1))
    B = np.zeros((state_num + 1,3))
    for q in range(0, gv.R+1):
        for i in range(0, N+1):
            for j in range(0, N - i+1):
                current_state = np.array([q, i, j])
                state_location = int (q * (N + 2) * (N + 1) / 2 + i * (2 * N + 3 - i) / 2 + j)
                UH_0 = 0
                if current_state[2]!=0:
                    UH_0 = np.sum(Mu[0:current_state[2]])


                A[state_location][state_location] = gv.Lambda + (current_state[2] > 0) * UH_0 + current_state[1] * gv.Thet

                row = q
                column = int(i * (2 * N + 3 - i) / 2) + j

                next_state_Lambda = current_state + e(f[row, column], 3)

                next_state_Lambda_location = int(next_state_Lambda[0] * (N + 2) * (N + 1) / 2 + next_state_Lambda[1] * (
                        2 * N + 3 - next_state_Lambda[1]) / 2 + next_state_Lambda[2])
                A[state_location][next_state_Lambda_location] = A[state_location][
                                                                    next_state_Lambda_location] - gv.Lambda

                if current_state[2] > 0:
                    if q>0:
                        if i>0:
                            temp_state = np.array([q-1,i-1,j])
                            temp_row = q-1
                            temp_column = int((i-1) * (2 * N + 3 - (i-1)) / 2) + j
                            next_state_mu = temp_state + e(f[temp_row, temp_column], 3)
                        else:
                            next_state_mu = current_state - e(1, 3)
                    else:
                        if i>0:
                            next_state_mu = current_state - e(2, 3)
                        else:
                            next_state_mu = current_state - e(3, 3)
                    next_state_mu_location = int(next_state_mu[0] * (N + 2) * (N + 1) / 2 + next_state_mu[1] * (
                            2 * N + 3 - next_state_mu[1]) / 2 + next_state_mu[2])
                    A[state_location][next_state_mu_location] = -UH_0

                if current_state[1] > 0:
                    next_state_setup = current_state - e(2, 3) + e(3, 3)
                    next_state_setup_location = int(next_state_setup[0] * (N + 2) * (N + 1) / 2 + next_state_setup[1] * (
                            2 * N + 3 - next_state_setup[1]) / 2 + next_state_setup[2])
                    A[state_location][next_state_setup_location] = - current_state[1] *gv.Thet

                A[state_location][state_num] = 1
                B[state_location][1:3] = Caculate_cx(current_state, N, Mu)
                B[state_location][0] = sum(weight *B[state_location][1:3])
    A[state_num][0] = 1
    B[state_num][0:3] = 0
    v = SOLVE(A, B)

    g = v[state_num]
    v = v[0:state_num]
    return v,g
def improvement(v,N,f):
    f1 = f.copy()
    for q in range(0, gv.R+1):
        for i in range(0, N+1):
            for j in range(0, N - i+1):
                current_state = np.array([q, i, j])
                row = q
                column = int(i * (2 * N + 3 - i) / 2) + j
                if q<gv.R:
                    if i+j<N:
                        Actions = np.array([1,2])
                        min_value = np.inf
                        min_aciton = -1
                        for k in range(0,len(Actions)):
                            new_action = Actions[k]
                            new_state = current_state+e(new_action,3)
                            new_state_location = int(new_state[0] * (N + 2) * (N + 1) / 2 + new_state[1] * (2 * N + 3 - new_state[1]) / 2 + new_state[2])
                            new_value = v[new_state_location][0]
                            if new_value < min_value:
                                min_value = new_value
                                min_aciton = new_action
                            else:
                                if new_value == min_value:
                                    min_aciton = f1[row][column]
                        f1[row][column] = min_aciton

    return f1
def DP(N,Mu,f,weight,g,v):

    t1 = time.time()
    it = 0
    flag = True
    while flag == True:
        it = it +1
        g_count = g
        [v, g] = evaluation(N,Mu,f,weight)
        f1 = improvement(v, N,f)
        temp = np.abs((g_count[0] - g[0]))
        if (f1 == f).all()==True: #or int(g_count[0]*1000)==int(g[0]*1000):
          break
        else:
          f = f1
    t2 = time.time()
    print('\r  ',str(it),'   cost',str(t2-t1),' s',end='')
    if gv.SRT ==1:
        gv.it1 = gv.it1 + int(it)
        gv.time1 = gv.time1+(t2-t1)
    else:
        gv.it2 = gv.it2 + int(it)
        gv.time2 = gv.time2 + (t2 - t1)
    # [v, g] = evaluation(N, Mu, f, weight)
    return g[1:3],f1,v[:,1:3]

def default_f(N,Mu,f,weight):
    [v, g] = evaluation(N,Mu,f,weight)
    return g[1:3],f,v[:,1:3]