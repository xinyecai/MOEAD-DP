import pickle

import GlobalValues as gv
import numpy as np
import HyperVolume as ea
from matplotlib import pyplot as plt
from main import OptimalQueueControl

def median(a):
    b = np.argsort(a)
    return b[int(len(b)/2)]

if __name__ == "__main__":
    Dir = 'MC/'
    Dir2 = 'ANOVA/'
    Dir3 = 'plot/'
    maxrun = 20
    max_break_count = 2
    for count in range(805,806):
        HV_size = 2500
        HV_accuracy = 0.01
        HV_list = list()
        for run in range(1,maxrun+1):
            f = open(Dir2+'DPS_' + str(count) + '_' + str(run) + ".txt", 'rb')
            ([res_ind_DPS, res_f_DPS, res_DPS, Mu, gv.Lambda, gv.R, gv.Thet]) = pickle.load(f)
            f.close()
            HV_list.append(ea.indicator.HV(res_DPS,gv.rf))
        median_run = median(HV_list)+1
        f = open(Dir2+'DPS_' + str(count) + '_' + str(median_run) + ".txt",'rb')
        # print('第',str(median_run),'次run:\n')
        ([res_ind_DPS, res_f_DPS, res_DPS, Mu, gv.Lambda, gv.R, gv.Thet]) = pickle.load(f)
        f.close()



        f = open(Dir2+'BETP_SO_' + str(count) + ".txt", 'rb')
        [res_ind_BETP, res_f_BETP, res_BETP,Mu,gv.Lambda,gv.R,gv.Thet] = pickle.load(f)
        f.close()
        N= len(Mu)
        for run in range(1, maxrun+1):

            f = open(Dir + Dir2 + '/plt_' + str(count) + '_' + str(run) + ".txt", 'rb')
            ([res_compare_DPS, _, Mu, gv.Lambda, gv.R, gv.Thet]) = pickle.load(f)
            f.close()

            print('\n ', count, ' ,', N, '  ',str(run),' \n')

            # print('\n DPS Simulation:\n')
            # res_compare_DPS = np.zeros([len(res_DPS), 2])
            #
            # reward_count_power = np.zeros([len(res_DPS)])
            # reward_count_WNr = np.zeros([len(res_DPS)])
            # Zet_count = np.zeros([len(res_DPS)])
            # OQC_set = list()
            # next_state_set = list()
            # for i in range(len(res_ind_DPS)):
            #     OQC = OptimalQueueControl(N, res_ind_DPS[i, :])
            #     # present_points_index_count = 0
            #     # next_state = OQC.start_point
            #     next_state_set.append(OQC.start_point)
            #     OQC.compareSet_init_new(res_f_DPS[i, :])
            #     OQC_set.append(OQC)
            # step = 0
            # # for step in range(1, present_points[-1] + 1):
            #
            # old_HV = np.inf
            # break_count = 0
            # while(True):
            #     step = step + 1
            #     for i in range(len(res_ind_DPS)):
            #         print('\r 第(',  (step),')步', end='')
            #         # action = OQC.policy_trans_my(res_f_DPS[i, :], next_state)
            #         # next_state, reward_power, reward_WNr, Zet = OQC.state_transation(next_state, action)
            #         next_state_set[i], reward_power, reward_WNr, Zet = OQC_set[i].state_transation(next_state_set[i], OQC_set[i], res_f_DPS[i, :], 4,res_ind_DPS[i])  # 1:default 2:setup-threshold 3.combination 4.new
            #
            #         reward_count_power[i] = reward_count_power[i] + reward_power
            #         reward_count_WNr[i] = reward_count_WNr[i] + reward_WNr
            #         Zet_count[i] = Zet_count[i] + Zet
            #     if step % HV_size==0:
            #         for i in range(len(res_ind_DPS)):
            #             res_compare_DPS[i, 0] = reward_count_power[i] / Zet_count[i]
            #             res_compare_DPS[i, 1] = reward_count_WNr[i] / Zet_count[i]
            #         r_DPS = ea.ndsortTNS(res_compare_DPS, 1)[0]
            #         index_DPS = np.where(r_DPS == 1)[0]
            #         result_DPS = res_compare_DPS[index_DPS]
            #         HV = ea.indicator.HV(np.array(result_DPS),gv.rf)
            #         if np.abs(old_HV-HV)<HV_accuracy:
            #             break_count = break_count +1
            #             if break_count >max_break_count:
            #                 break
            #         else:
            #             break_count = 0
            #         print('old_HV = ', str(old_HV), ',HV = ', str(HV), 'break_count = ', str(break_count), '\n')
            #         old_HV = HV

            r_DPS = ea.ndsortTNS(res_compare_DPS, 1)[0]
            index_DPS = np.where(r_DPS == 1)[0]
            result_DPS = res_compare_DPS[index_DPS]
            step_count = step

            print('\n BETP Simulation:\n')
            res_compare_BETP = np.zeros([len(res_BETP), 2])

            reward_count_power = np.zeros([len(res_BETP)])
            reward_count_WNr = np.zeros([len(res_BETP)])
            Zet_count = np.zeros([len(res_BETP)])
            OQC_set = list()
            next_state_set = list()
            for i in range(len(res_ind_BETP)):
                OQC = OptimalQueueControl(N, res_ind_BETP[i, :])
                # present_points_index_count = 0
                # next_state = OQC.start_point
                next_state_set.append(OQC.start_point)
                # OQC.compareSet_init_new(res_f_DPS[i, :])
                OQC_set.append(OQC)
            step = 0
            old_HV = np.inf
            break_count = 0
            while (True):
                step = step + 1
                for i in range(len(res_ind_BETP)):
                    print('\r 第(', (step), ')步', end='')
                    next_state_set[i], reward_power, reward_WNr, Zet = OQC_set[i].state_transation(next_state_set[i], OQC_set[i])  # 1:default 2:setup-threshold 3.combination 4.new

                    reward_count_power[i] = reward_count_power[i] + reward_power
                    reward_count_WNr[i] = reward_count_WNr[i] + reward_WNr
                    Zet_count[i] = Zet_count[i] + Zet
                if step % HV_size == 0:
                    for i in range(len(res_ind_BETP)):
                        res_compare_BETP[i, 0] = reward_count_power[i] / Zet_count[i]
                        res_compare_BETP[i, 1] = reward_count_WNr[i] / Zet_count[i]
                    r_BETP = ea.ndsortTNS(res_compare_BETP, 1)[0]
                    index_BETP = np.where(r_BETP == 1)[0]
                    result_BETP = res_compare_BETP[index_BETP]
                    HV = ea.indicator.HV(np.array(result_BETP),gv.rf)
                    if np.abs(old_HV - HV) < HV_accuracy:
                        break_count = break_count + 1
                        if break_count > max_break_count:# and step>=step_count:
                            break
                    else:
                        break_count = 0
                    print('old_HV = ', str(old_HV), ',HV = ', str(HV), 'break_count = ', str(break_count), '\n')
                    old_HV = HV
            r_BETP = ea.ndsortTNS(res_compare_BETP, 1)[0]
            index_BETP = np.where(r_BETP == 1)[0]
            result_BETP = res_compare_BETP[index_BETP]

            f = open( Dir + Dir2 + '/plt_' + str(count)+'_'+str(run) + ".txt", 'wb+')
            pickle.dump([res_compare_DPS, res_compare_BETP, Mu, gv.Lambda, gv.R, gv.Thet], f)
            f.close()


            fig = plt.figure(figsize=(8, 8))
            ax = fig.add_subplot(111)
            plt_BETP_f1 = np.array(result_BETP)[:, 0]
            plt_BETP_f2 = np.array(result_BETP)[:, 1]
            plt_DPS_f1 = np.array(result_DPS)[:, 0]
            plt_DPS_f2 = np.array(result_DPS)[:, 1]
            plt_DPS = ax.scatter(plt_DPS_f1, plt_DPS_f2, marker="o", color='white', edgecolors='r')
            plt_BETP = ax.scatter(plt_BETP_f1, plt_BETP_f2, marker="+", c='b')
            plt.title("Mu = " + ''.join(' %s ' % id for id in Mu) + "\n Lambda = " + str(gv.Lambda) + " R = " + str(
                gv.R) + "Theta = " + str(gv.Thet) + 'step = ' + str(step))
            plt.legend([plt_DPS,plt_BETP], ['MOEAD-DP','BETP'], loc='upper right',fontsize='xx-large')
            plt.xlabel = 'PowerConsume'
            plt.ylabel = 'RejectRate'
            ax.set_xlabel('PowerConsumption', fontsize=18, labelpad=12.5)
            ax.set_ylabel('RequestNumber', fontsize=18, labelpad=12.5)
            fig.savefig( str(Dir)+ str(Dir2)+str(Dir3) + 'HV_NDSort_Sample' + str(count) + '_N=' + str(
                N) + '_Lambda=' + str(int(gv.Lambda)) + '_R=' + str(
                gv.R) + '_Theta=' + str(
                gv.Thet) + '_' + str(run) + ".pdf")
            plt.close()

            fig = plt.figure(figsize=(8, 8))
            ax = fig.add_subplot(111)
            plt_DPS_f1 = np.array(res_compare_DPS)[:,0]
            plt_DPS_f2 = np.array(res_compare_DPS)[:,1]
            plt_DPS = plt.scatter(plt_DPS_f1, plt_DPS_f2, marker="o",color='white',edgecolors='r')

            plt_BETP_f1 = np.array(res_compare_BETP)[:,  0]
            plt_BETP_f2 = np.array(res_compare_BETP)[:,  1]
            plt_BETP = plt.scatter(plt_BETP_f1, plt_BETP_f2, marker="+",edgecolors='b')

            plt.title("Mu = " + ''.join(' %s ' % id for id in Mu) + "\n Lambda = " + str(gv.Lambda) + " R = " + str(
                gv.R) + "Theta = " + str(gv.Thet))

            plt.legend([plt_DPS , plt_BETP], ['MOEAD-DP', 'BETP'], loc='upper right',fontsize='xx-large')
            ax.set_xlabel('Power Consumption',fontsize=18,labelpad = 12.5)
            ax.set_ylabel('Number of Requests',fontsize=18,labelpad = 12.5)
            fig.savefig(str(Dir) + str(Dir2)+str(Dir3) + 'HV_Sample' + str(count) + '_N=' + str(
                    N) + '_Lambda=' + str(int(gv.Lambda)) + '_R=' + str(
                    gv.R) + '_Theta=' + str(
                    gv.Thet) + '_' + str(run) + ".pdf")
            plt.close()

