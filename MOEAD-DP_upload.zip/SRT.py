import numpy as np
import GlobalValues as gv
def binary_search(arr,start,end,key):
    index = np.where(arr==key)[0]
    if len(index)==0:
        while start < end:
            mid = start + int((end - start) / 2)
            if arr[mid] < key:
                start = mid + 1
            else:
                end = mid - 1
        if arr[end] > key:
            t = end-1
        else:
            t = end
        return (np.where(arr==arr[t])[0])
    else:
        return index

def f2SRT(Mu,res_f,N):  #state-action table to rate-action table
    if res_f.size==1:
        return None
    s = []
    for i in range(0, N + 1):
        for j in range(0, N - i + 1):
            column = int(i * (2 * N + 3 - i) / 2) + j
            temp = list()
            temp.append(np.sum(Mu[0:j]))
            temp.append(np.sum(Mu[j:i + j]))
            s.append(temp + res_f[:, column].tolist())
    data = np.array(s)
    index = np.lexsort([data[:, 1], data[:, 0]])
    return data[index, :]

def SRT2f(srt,Mu,N):    #rate-action table to state-action table
    f = 2*np.ones((gv.R+1,int((N+2)*(N+1)/2)),dtype=np.int32)
    for q in range(0, gv.R + 1):
        for i in range(0, N + 1):
            for j in range(0, N - i + 1):
                row = q
                column = int(i * (2 * N + 3 - i) / 2) + j
                hot_rate = np.sum(np.sum(Mu[0:j]))
                setup_rate = np.sum(np.sum(Mu[j:i + j]))
                index1 = binary_search(srt[:, 0], 0, len(srt[:, 0]) - 1, hot_rate)
                index2 = binary_search(srt[index1, 1], 0, len(srt[index1, 1]) - 1, setup_rate)
                action = int(srt[index1, :][index2, 2 + q][0])
                if q < gv.R:
                    if i + j < N:
                        f[row][column] = action
                    else:
                        f[row][column] = 1
                else:
                    if i + j < N:
                        f[row][column] = 2
                    else:
                        f[row][column] = 0
    return f