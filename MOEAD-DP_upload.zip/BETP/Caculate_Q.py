import GlobalValues as gv;
import numpy as np;
def Caculate_Q(n,Mu,M):
    Q = np.zeros((M,M))
    f = [0]*M;
    Location = [[0 for i in range(n + gv.R +1)] for i in range(n + 1)]
    count = -1;
    for i in range(n+1):
         for j in range(i,n + gv.R+1):
             count = count + 1
             if i == 0:
                f[count]=0
             else:
                 f[count] = Mu[i-1]
    count = 0
    for j in range( n + gv.R+1):
        for i in range(min(n,j)+1):
            Location[i][j] = count
            count = count +1
    Q[Location[0][0],Location[0][1]] = gv.Lambda;
    for j in range(1,n+gv.R+1):
        if j!=n+gv.R:
            Q[Location[0][j],Location[0][j+1]] = gv.Lambda
        Q[Location[0][j],Location[1][j]]=gv.Thet
    u = np.cumsum(Mu)
    for i in range(1,n+1):
        for j in range(i,n+gv.R+1):
            if j==i:
                Q[Location[i][j],Location[i-1][j-1]] = u[i-1]
            else:
                Q[Location[i][j],Location[i][j - 1]] = u[i - 1]
            if j!=n+gv.R:
                Q[Location[i][j],Location[i][j + 1]] = gv.Lambda
            if i!=n and j!=i:
                # print(i,j,n)
                Q[Location[i][j],Location[i+1][j]] = gv.Thet


    for i in range(M):
        # print(Q)
        # print(-np.sum(Q[i,:]))
        Q[i,i] = -np.sum(Q[i])
    # print(Q)
    return Q,Location;

if __name__ == "__main__":
    n = 2
    Mu = [6,3]
    M = (n+2+2*gv.R)*(n+1)
    M = int(M/2)
    Q = Caculate_Q(n, Mu, M)
