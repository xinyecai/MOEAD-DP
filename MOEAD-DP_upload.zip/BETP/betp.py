import pickle

from matplotlib import pyplot as plt
from numpy.linalg import solve

import GlobalValues as gv
import numpy as np


def findMin(array):
    # array = np.array(array)
    if array == None or len(array) <= 0:

        return 0
    mins = 0
    i = 0
    j= 0
    while i < len(array):
        while j < len(array):
            if abs(array[i][j]) > abs(mins):
                mins = array[i][j]
            j +=1
        i += 1
    return mins

class BETP:
    def __init__(self, Mu, N):
        self.dimension = len(Mu)
        self.objFuncNum = 2
        self.isMin = True
        self.Mu = Mu
        self.server_num = N
    def Caculate_Q(self,Mu):
        M = int((self.server_num+2+2*gv.R)*(self.server_num+1)/2)
        Q = np.zeros([M,M])
        Location = np.zeros([self.server_num+1,self.server_num+gv.R+1],dtype=np.int)

        for i in range(self.server_num+1):
            for j in range(i,self.server_num+gv.R+1):
                k = 1
                for q in range(j):
                    if q<=self.server_num:
                        k = k+q+1
                    else:
                        k = k+self.server_num+1
                k = k+i
                Location[i,j] = np.int(k-1)

        a = Location[0,0]
        b = Location[0,1]
        c = Q[a,b]
        Q[Location[0,0],Location[0,1]] = gv.Lambda
        for j in range(2,self.server_num+gv.R+2):
            if j!=self.server_num+gv.R+1:
                Q[Location[0,j-1],Location[0,j]] = gv.Lambda
            Q[Location[0,j-1],Location[1,j-1]] = gv.Thet
        for i in range(2,self.server_num+2):
            u = np.cumsum(Mu)
            for j in range(i,self.server_num+gv.R+2):
                if j==i:
                    Q[Location[i-1, j - 1], Location[i-2, j - 2]] = u[i-2]
                else:
                    Q[Location[i - 1, j - 1], Location[i - 1, j - 2]] = u[i - 2]
                if j!=self.server_num+gv.R+1:
                    Q[Location[i-1, j - 1], Location[i-1, j]] = gv.Lambda
                if i!=self.server_num+1 and j!=i:
                    Q[Location[i - 1, j - 1], Location[i, j - 1]] = gv.Thet
        for i in range(1,M+1):
            Q[i-1,i-1] = -np.sum(Q[i-1,:])
        return Location,Q,M
    def Caculate_power(self,k,Mu,Nr,NH):
        if k<NH:
            p = gv.Pc+gv.a*(np.power(Mu[k],gv.Alpha))
        else:
            if k==NH and Nr !=0:
                p = gv.Pc + gv.a * (np.power(Mu[k], gv.Alpha))
            else:
                p = gv.Pc
        return p
    def Caculate_y_2(self,Nr,NH,Mu):

        WNr = Nr/(self.server_num+gv.R)
        mu_count = 0
        for k in range(1,self.server_num+1):
            mu_count = mu_count + self.Caculate_power(k-1,Mu,Nr,self.server_num)
        p = list()
        if NH==self.server_num:
            for k in range(1,NH+1):
                p.append(self.Caculate_power(k-1,Mu,Nr,NH))
            p.append(0)
        else:
            if NH!=Nr:
                for k in range(1,NH+2):
                    p .append(self.Caculate_power(k-1, Mu, Nr, NH))
            else:
                for k in range(1,NH+1):
                    p.append(self.Caculate_power(k-1, Mu, Nr, NH))
                p.append(0)
        p = np.array(p)
        p = np.sum(p)/mu_count
        return WNr,p
    def evaluation(self, Mu,weight,g=None,f=None,v=None,srt=None):
        Location,Q,M = self.Caculate_Q(Mu)
        V = np.zeros([M+1,M+3])
        for i in range(1,self.server_num+2):
            for j in range(i,self.server_num+gv.R+2):
                k = Location[i-1,j-1]
                V[k,k] = 1;
                Zet = -(1/Q[k,k])
                NH = i-1
                Nr = j-1
                UH_0 = np.sum(Mu[0:NH])
                WNr,power = self.Caculate_y_2(Nr,NH,Mu)
                V[k,M] =  Zet
                V[k, M + 1]=   WNr *Zet
                V[k,M+2] = power * Zet
                if j<self.server_num+gv.R+1:
                    X_Zet = [i-1,j]
                    p = gv.Lambda *Zet
                    t = Location[X_Zet[0],X_Zet[1]]
                    V[k,t] = p
                if i<self.server_num+1 and i<j:
                    X_Zet = [i,j-1]
                    p = gv.Thet *Zet
                    t = Location[X_Zet[0],X_Zet[1]]
                    V[k,t] = p
                if j>i and i>1:
                    X_Zet = [i-1,j-2]
                    p = UH_0 *Zet
                    t = Location[X_Zet[0],X_Zet[1]]
                    V[k,t] = p
                if i==j and i>1:
                    X_Zet = [i-2,j-2]
                    p = UH_0 *Zet
                    t = Location[X_Zet[0],X_Zet[1]]
                    V[k,t] = p

        A = np.zeros((M + 1, M + 1))
        B = np.zeros((M + 1, 2))
        for i in range(1,M+1):
            A[i-1,i-1] = 1
            for j in range(1,M+1):
                if j==i:
                    A[i-1,j-1] = 1
                else:
                    A[i-1,j-1] = -V[i-1,j-1]
            A[i-1,M] = V[i-1,M]
            B[i,0] = V[i,M+1]
            B[i,1] = V[i,M+2]
        A[M,0] = 1
        v = solve(A, B)
        g = v[M, :]
        v = v[0:M, :]
        return g,np.array([0]),np.array([0])