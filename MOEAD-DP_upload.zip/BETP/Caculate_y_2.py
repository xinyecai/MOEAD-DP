import GlobalValues as gv;
import numpy as np;
def Caculate_power(Nr,NH,k,n,mu,Mu):
    p=0
    if k<NH:
        p = gv.Pc+gv.a * (np.power(mu[k],gv.Alpha))
    else:
        if k==NH and Nr!=0:
            p = gv.Pc + ((np.sum(mu)-gv.Lambda)*gv.Thet+gv.Lambda*(np.sum(mu)+gv.Lambda)*gv.a*np.power(mu[k],gv.Alpha))/((gv.Lambda+gv.Thet)*np.sum(mu))
        else:
            p = gv.Pc
    return p

def Caculate_y_2(Nr,NH,mu,n,Mu):
    WNr = Nr/(n+gv.R)
    mu_count = 0
    for k in range(n):
        mu_count = mu_count + Caculate_power(Nr,n,k,n,mu,Mu)

    p = []
    if NH ==n:
        for k in range(NH):
            p.append(Caculate_power(Nr,NH,k,n,mu,Mu))
        p.append(0)
    else:
        if NH!=Nr:
            for k in range(NH+1):
                p.append(Caculate_power(Nr,NH,k,n,mu,Mu))
        else:
            for k in range(NH):
                p.append(Caculate_power(Nr, NH, k, n, mu, Mu))
            p.append(0)

    for i in range(len(p)):
        p[i] = p[i]/mu_count
    sum_p = np.sum(p)
    return WNr,sum_p

if __name__ == "__main__":
    n = 2
    Mu = [6,5]
    M = (n+2+2*gv.R)*(n+1)
    M = int(M/2)
    NH = 1
    Nr = 3
    mu = Mu
    y1,y2 = Caculate_y_2(Nr,NH,mu,n,Mu)