import GlobalValues as gv;
import numpy as np;
from scipy import linalg

from BETP.Caculate_Q import Caculate_Q


def Caculate_Pi(Q):
    M=len(Q)
    # b = np.ones((1, M))
    A = Q.T
    A = A[range(M-1)]
    A = np.vstack((A,np.ones((1, M))))

    b = np.zeros((M-1,1))
    b = np.vstack((b, np.ones((1, 1))))
    Pi=linalg.solve(A,b)
    return Pi
if __name__=="__main__":
    n = 2
    Mu = [6, 5]
    M = (n + 2 + 2 * gv.R) * (n + 1)
    M = int(M / 2)
    Q = Caculate_Q(n, Mu, M)
    Pi = Caculate_Pi(Q)

