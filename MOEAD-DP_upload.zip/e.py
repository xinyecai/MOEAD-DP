import numpy as np
def e(k,length):
    A = np.zeros(length)
    if k!=0:
        A[k-1] = 1
    return A