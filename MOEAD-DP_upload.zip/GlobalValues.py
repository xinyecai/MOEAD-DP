import numpy as np
Lambda = 44.1
R = 2
Thet = 1
Pc = 0
a = 1
Alpha = 3
exchange_size = 1
exchange_prob = 0.9
mutation_prob = 0.1
iteration = 100
mutation_size = 2
accuracy = 6
target = 0
rf  = np.ones([1,2])
SRT=1##1:SRT 0:init_f else:f
it1 = int(0)
it2 = int(0)
time1 = float(0)
time2 = float(0)
font2 = {'family': 'Times New Roman',
         'size': 18,
         }
epsilon = 0.5
color = {
    'TMOEA/D-DP': 'r',
    'MOEA/D-SF': 'b',
    'MOEA/D-WF': 'y',
    'FSF-DP': 'g',
    'FSF-WF': 'brown',
    'FSF-SF': 'violet',
    'BETP': 'm',
    'BETP_MO': 'orange',
    'MOEA/D-BETP': 'orange'
}
mark = {
    'TMOEA/D-DP': 'o',
    'MOEA/D-SF': '+',
    'MOEA/D-WF': '*',
    'FSF-DP': 'x',
    'FSF-WF': 'v',
    'FSF-SF': '^',
    'BETP': 's',
    'BETP_MO': 'd',
    'MOEA/D-BETP': 'd'
}