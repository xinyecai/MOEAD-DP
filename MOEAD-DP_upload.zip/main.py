import copy
import random
import pickle


import GlobalValues as gv
import numpy as np
import DP
import time
import moea_d
import HyperVolume as ea

from BETP.betp import BETP


def best_sequence(arr):
    '''Find longest ascending sequence in an array'''
    arr_length = len(arr)
    if arr_length <= 1:
        return arr
    longest = [1]  # will store the length of the longest sequence ending on this index
    back_link = [-1]  # link to the previous element in the longest sequence or -1
    best_idx_at_all = 0
    for idx in range(1, arr_length):
        best_len_so_far = 1
        back = -1
        for i in range(len(longest) + 1):
            if arr[i] < arr[idx] and best_len_so_far <= longest[i]:
                best_len_so_far = longest[i] + 1
                back = i
        back_link.append(back)
        longest.append(longest[back] + 1 if back > -1 else 1)
        if longest[best_idx_at_all] < longest[idx]:
            best_idx_at_all = idx

    nxt = best_idx_at_all
    result = []
    while nxt >= 0:
        result.append(arr[nxt])
        nxt = back_link[nxt]

    return np.array(list(reversed(result)))

def binary_search(arr,start,end,key):
    index = np.where(arr==key)[0]
    if len(index)==0:
        while start < end:
            mid = start + int((end - start) / 2)
            if arr[mid] < key:
                start = mid + 1
            else:
                end = mid - 1
        if arr[end] > key:
            t = end-1
        else:
            t = end
        return (np.where(arr==arr[t])[0])
    else:
        return index

def e_functon(k,len):
    A = np.zeros(len,dtype=int)
    if k != 0:
        A[k - 1] = 1
    return A
class OptimalQueueControl:
    def __init__(self,N,Mu):
        self.dimension = len(Mu)
        self.objFuncNum = 2
        self.isMin = True
        self.Mu = Mu
        self.server_num = N
        self.start_point = self.init_start_point()  #start point of simulation
        self.Max_Power = self.max_power()
    def init_start_point(self):
        temp = np.zeros(self.server_num+1,dtype=np.int)
        temp[0] = random.randint(0,gv.R)
        for i in range(len(self.Mu)):
            temp[i+1] = random.randint(0,2)
        return temp
    # def compareSet_init(self,res_f):
    #     s = []
    #     for i in range(0, self.server_num + 1):
    #         for j in range(0, self.server_num - i + 1):
    #             for q in range(0, gv.R + 1):
    #                 current_state = np.array([q, i, j])
    #                 row = q
    #                 column = int(i * (2 * self.server_num + 3 - i) / 2) + j
    #                 if res_f[row, column] == 2:
    #                     s.append([np.sum(self.Mu[0:j]), np.sum(self.Mu[j:i + j]), q])
    #                     break
    #     data = np.array(s)
    #     index = np.lexsort([data[:, 1], data[:, 0]])
    #     self.compareSet = data[index, :]
    def compareSet_init_new(self, res_f):   #initial policy
        s = []
        for i in range(0, self.server_num + 1):
            for j in range(0, self.server_num - i + 1):
                # for q in range(0, gv.R + 1):
                    # current_state = np.array([q, i, j])
                    # row = q
                column = int(i * (2 * self.server_num + 3 - i) / 2) + j
                    # if res_f[row, column] == 2:
                     # s.append([np.sum(self.Mu[0:j]), np.sum(self.Mu[j:i + j]), res_f[]])
                temp = list()
                temp.append(np.sum(self.Mu[0:j]))
                temp.append(np.sum(self.Mu[j:i + j]))
                s.append(temp + res_f[:,column].tolist())
                        # break
        data = np.array(s)
        index = np.lexsort([data[:, 1], data[:, 0]])
        self.compareSet = data[index, :]
        #
        # temp = best_sequence(self.Mu)
        # temp_index = np.zeros(len(temp),dtype=int)
        # m = self.Mu.tolist()
        # for i in range(len(temp)):
        #     temp_index[i] = m.index(temp[i])
        #
        # self.compareSet = data[np.array(temp_index),:]
    def max_power(self):
        power_count = 0
        for i in range(self.server_num):
            power_count = power_count+DP.Caculate_power(i, self.Mu, 2)
        return power_count
    def prob_caculate(self,next_states,next_prob,state,prob):
        if len(next_states)==0:
            next_states.append(state)
            next_prob.append(prob)
        else:
            flag = True
            for i in range(len(next_states)):
                x = next_states[i]
                if (x==state).all()==True:
                    flag = False
                    next_prob[i] = next_prob[i]+prob
                    break
            if flag ==True:
                next_states.append(state)
                next_prob.append(prob)
        return next_states,next_prob
    def state_transation(self,state,OQC,res_f=None,type=None,res_ind=None):
        Zet = 0
        WNr = (state[0] + len(np.where(state[1:self.server_num + 1] != 0)[0])) / (gv.R + self.server_num)
        power = 0
        next_states = list()
        next_prob = list()
        if state[0] < gv.R or len(np.where(state[1:self.server_num + 1] == 0)[0]) > 0:
            Zet = Zet + gv.Lambda
            if type ==1:
                 action = OQC.policy_trans_my_test(res_f, state)
            else:
                if type ==2:
                    action = OQC.policy_trans_my(res_f, state)
                else:
                    if type ==3:
                        action = OQC.policy_trans_my_combination(res_f,res_ind,state)
                    else:
                        if type ==4:
                            action = OQC.policy_trans_SRT(res_f, state)
                        else:
                            action = OQC.policy_trans_BETP(state)
            next_states,next_prob = self.prob_caculate(next_states, next_prob, state + action, gv.Lambda)
        for i in range(1, self.server_num + 1):
            state_value = state[i]
            if state_value == 0:
                123
            else:
                if state_value == 1:#setup
                    power = power + DP.Caculate_power(i - 1, self.Mu, 1)
                    Zet = Zet + gv.Thet
                    next_states,next_prob = self.prob_caculate(next_states, next_prob, state + e_functon(i+1,len(state)), gv.Thet)
                else:
                    if state_value == 2:#hot
                        power = power + DP.Caculate_power(i - 1, self.Mu, 2)
                        Zet = Zet + self.Mu[i - 1]
                        if type ==None:
                             next_states, next_prob = self.prob_caculate(next_states, next_prob, state - 2*e_functon(i+1, len(state)) +(state[0]>0)*(2*e_functon(i+1, len(state))-e_functon(1,len(state))),self.Mu[i-1])
                        else:
                            setup_array = list()#setup servers
                            for k in range(1, len(state)):
                                if state[k] == 1:
                                    setup_array.append(self.Mu[k - 1])
                            if len(setup_array)>0:
                                temp_list = list(set(setup_array))
                                if type == 3:
                                    ind = OQC.combination_ind_index(res_ind,state)
                                    temp_list.sort(key=(res_ind[ind].tolist()).index)
                                else:
                                    temp_list.sort(key=(self.Mu.tolist()).index)
                                setup_server = e_functon(np.where(self.Mu == temp_list[-1])[0] + 2, len(state))#关闭优先级最低的setup server
                            if state[0] > 0:
                                if len(setup_array)>0:
                                    temp_state = copy.deepcopy(state)
                                    temp_state[0] = temp_state[0]-1
                                    temp_state = temp_state - setup_server

                                    if type == 1:
                                        action = OQC.policy_trans_my_test(res_f, temp_state)
                                    else:
                                        if type == 2:
                                            action = OQC.policy_trans_my(res_f, temp_state)
                                        else:
                                            if type==3:
                                                action = OQC.policy_trans_my_combination(res_f, res_ind, temp_state)
                                            else:
                                                action = OQC.policy_trans_SRT(res_f, temp_state)
                                    next_states, next_prob = self.prob_caculate(next_states, next_prob, temp_state + action,
                                                                                self.Mu[i - 1])
                                else:
                                    next_states, next_prob = self.prob_caculate(next_states, next_prob, state - e_functon(1, len(state)),self.Mu[i - 1])
                            else:
                                if len(setup_array)>0:
                                    next_states, next_prob = self.prob_caculate(next_states, next_prob, state - setup_server,self.Mu[i - 1])

                                else:
                                    next_states, next_prob = self.prob_caculate(next_states, next_prob, state - 2*e_functon(i+1, len(state)),self.Mu[i - 1])

        power = power/self.Max_Power
        next_prob = np.array(next_prob)
        next_prob = next_prob/Zet
        next_prob = np.cumsum(next_prob)
        rand = random.random()
        next_state = []
        Zet = 1/Zet
        for i in range(len(next_prob)):
           if rand<next_prob[i]:
               next_state = next_states[i]
               break
        reward_power = Zet * power
        reward_WNr = Zet * WNr
        if len(next_state)==0:
            print('error:next_state \n')
        return next_state,reward_power,reward_WNr,Zet

    def policy_trans_SRT(self,res_f,state):
        queue_length = state[0]
        idle_list = np.where(state[1:len(state)]==0)[0]
        if len(idle_list) ==0:
            if queue_length==gv.R:
                action = np.zeros(len(state), dtype=int)
            else:
                action = e_functon(1, len(state))
        else:
            begin_index = idle_list[0]
            setup_index = np.where(state[1:len(state)]==1)[0]
            hot_index = np.where(state[1:len(state)] == 2)[0]
            setup_rate = np.sum(self.Mu[setup_index])
            hot_rate = np.sum(self.Mu[hot_index])
            index1 = binary_search(self.compareSet[:, 0], 0, len(self.compareSet[:, 0]) - 1, hot_rate)
            index2 = binary_search(self.compareSet[index1, 1], 0, len(self.compareSet[index1, 1]) - 1, setup_rate)
            action = int(self.compareSet[index1, :][index2, 2+queue_length][0])
            if action ==1:
                action = e_functon(1, len(state))
            else:
                action = e_functon(begin_index + 2, len(state))
        return action

    def policy_trans_BETP(self, state):
        queue_length = state[0]
        idle_list = np.where(state[1:len(state)] == 0)[0]
        if len(idle_list) == 0:
            if queue_length==gv.R:
                action = np.zeros(len(state), dtype=np.int)
            else:
                action = e_functon(1,len(state))#the action of putting the request into the queue
        else:
            begin_index = idle_list[0]
            action = e_functon(begin_index+2,len(state))
        return action

def produce_mu(amount,num): #produce random mu
    amount = amount *10
    list1 = []
    for i in range(0,num-1):
        a = random.randint(20,amount)
        list1.append(a)

    list1.sort()
    list1.append(amount)

    list2 = []
    for i in range(len(list1)):
        if i == 0:
            b = list1[i]
        else:
            b = list1[i] - list1[i-1]
            if b<20:
                list2[i-1] = list2[i-1] -10
                b = b+10
        list2.append(b)
    return np.array(list2)/10
if __name__ == "__main__":
    maxGeneration =200
    stepLength = 199
    T = 6
    maxrun = 20
    Dir2 = ''
    Dir = ''
    sample_begin = 0
    sample_end =1
    for count in range(sample_begin, sample_end):#len(Lambda_set)
        start_time = time.time()
        N = 14
        #generate service rates randomly
        Mu_1 = np.array([random.randint(0, 20) for i in range(N)])
        Mu_2 = np.array([random.random() for i in range(N)])
        Mu = np.array([np.int((Mu_1[i] + Mu_2[i]) * 10) / 10 for i in range(N)])
        while moea_d.judgeDuplicated(Mu) == True:
            Mu_1 = np.array([random.randint(0, 20) for i in range(N)])
            Mu_2 = np.array([random.random() for i in range(N)])
            Mu = np.array([np.int((Mu_1[i] + Mu_2[i]) * 100) / 100 for i in range(N)])


        N = len(Mu)
        rate = np.sum(Mu)
        gv.Lambda = 5
        gv.Thet = 3
        gv.R = 2
        # print(('./ANOVA/' + Dir + Dir2 + 'DPS_' + str(count) + '_' + str(0) + ".txt", 'rb\n'))
        # f = open('./ANOVA/' + Dir + Dir2 + 'DPS_' + str(count) + '_' + str(1) + ".txt", 'rb')
        # [res_ind_DPS,res_f_DPS,res_DPS,Mu,gv.Lambda,gv.R,gv.Thet]=pickle.load(f)
        # f.close()

        print(Mu, '\n Theta = ', gv.Thet, ' Lambda = ', gv.Lambda, ' R = ', gv.R, '\n')
        for run in range(1,1+maxrun):
            print('\n count = ', count, ' , N = ', N, ' ,  run: (',run,'/',maxrun,') ')

            print('MOEAD with DP:\n')
            res_DPS = list()
            res_ind_DPS = list()
            res_f_DPS = list()
            DPS = moea_d.DynamicProgramingSolution(Mu, N)
            moea_DPS = moea_d.MOEAD(DPS,maxGeneration = maxGeneration,stepLength = stepLength,T = T )
            EP,EP_ind,EP_f = moea_DPS.run()
            for e in EP:
                res_DPS.append(e)
            res_DPS = np.array(res_DPS)
            r_DPS = ea.ndsortTNS(res_DPS, 1)[0]
            index_DPS = np.where(r_DPS == 1)[0]
            res_DPS = res_DPS[index_DPS]

            res_ind_DPS = EP_ind[index_DPS]
            res_f_DPS = EP_f[index_DPS]

            f = open('./ANOVA/'+Dir+Dir2+'DPS_' + str(count)+'_'+str(run)+ ".txt", 'wb+')
            pickle.dump([res_ind_DPS,res_f_DPS,res_DPS,Mu,gv.Lambda,gv.R,gv.Thet], f)
            f.close()

            print('\n BETP_MO:\n')
            betp = BETP(Mu, N)
            res_BETP = list()
            res_ind_BETP = list()
            res_f_BETP = list()
            moea = moea_d.MOEAD(betp, maxGeneration = maxGeneration, stepLength = stepLength, T = T)
            EP, EP_ind,EP_f = moea.run()
            for e in EP:
                res_BETP.append(e)
            res_BETP = np.array(res_BETP)
            r_BETP = ea.ndsortTNS(res_BETP, 1)[0]
            index_BETP = np.where(r_BETP == 1)[0]

            res_BETP = res_BETP[index_BETP]
            res_ind_BETP = EP_ind[index_BETP]
            res_f_BETP = EP_f[index_BETP]

            f = open('./MC/'+Dir+Dir2+'BETP_MO_' + str(count) + '_'+str(run)+".txt", 'wb+')
            pickle.dump([res_ind_BETP, res_f_BETP, res_BETP,Mu,gv.Lambda,gv.R,gv.Thet], f)
            f.close()

