import copy
import random
import GlobalValues as gv
import numpy as np

from DP import DP, default_f
import HyperVolume as ea
from SRT import f2SRT,SRT2f


def get_permutation(seq,n):
   s = np.array(copy.deepcopy(seq))
   temp=[]
   for i in range(n):
       index = random.randint(0,len(s)-1)
       temp.append(s[index])
       s = np.delete(s,index)
   return np.array(temp)

def permutations(seq):
   seq = np.sort(seq)
   size = seq.shape[0]
   isVisited = [False for i in range(size)]
   temp = [None for i in range(size)]
   result = []
   def dfs(pos):
      if pos == size:
         result.append(copy.deepcopy(temp))
         return
      for i in range(size):
         if i>0 and seq[i]==seq[i-1] and not isVisited[i-1]:
            continue
         if not isVisited[i]:
            temp[pos] = seq[i]
            isVisited[i] = True
            dfs(pos+1)
            isVisited[i] = False
   dfs(0)
   return np.array(result)
def produceWeight(dimension, stepLength):
   """
   :param dimension:
   :param stepLength:
   :return:
   """
   seq = np.concatenate((np.zeros(stepLength), np.ones(dimension-1)))
   seqAll = permutations(seq)
   weights = []
   for i in range(seqAll.shape[0]):
      index = np.where(seqAll[i] > 0)[0]
      index += 1
      index1 = np.append(index, dimension+stepLength)
      index2 = np.insert(index, 0, 0)
      weight = ((index1 - index2) - 1) / stepLength
      weights.append(weight)
   return np.array(weights)
class DynamicProgramingSolution:
    def __init__(self,Mu,N):
        self.dimension = len(Mu)
        self.objFuncNum = 2
        self.isMin = True
        self.Mu = Mu
        self.server_num = N
        self.init_f = 2*np.ones((gv.R+1,int((N+2)*(N+1)/2)),dtype=np.int32)
        for q in range(0, gv.R + 1):
            for i in range(0, N + 1):
                for j in range(0, N - i + 1):
                    row = q
                    column = int(i * (2 * N + 3 - i) / 2) + j
                    if q < gv.R:
                        if i + j < N:
                            self.init_f[row][column] = 2
                        else:
                            self.init_f[row][column] = 1
                    else:
                        if i + j < N:
                            self.init_f[row][column] = 2
                        else:
                            self.init_f[row][column] = 0
    def evaluation(self,X,weight,g=np.array([10000,10000,10000]),f=None,v=None,srt=None):
        if gv.SRT==1:## using srt
            if srt is not None:
                f = SRT2f(srt,X, self.server_num)
            else:
                if f is None:
                    f = self.init_f
        else:
            if gv.SRT==0:## static policy init_f
                f = self.init_f
            else:## using f
                if f is None:
                    f = self.init_f
        g,f,v = DP(self.server_num,X,f,weight,g,v)
        return g,f,v
class DefaultSolution:
    def __init__(self,Mu,N,policy=2):
        self.dimension = len(Mu)
        self.objFuncNum = 2
        self.isMin = True
        self.Mu = Mu
        self.server_num = N
        self.init_f = 2*np.ones((gv.R+1,int((N+2)*(N+1)/2)),dtype=np.int32)
        for q in range(0, gv.R + 1):
            for i in range(0, N + 1):
                for j in range(0, N - i + 1):
                    row = q
                    column = int(i * (2 * N + 3 - i) / 2) + j
                    if q < gv.R:
                        if i + j < N:
                            self.init_f[row][column] = policy
                        else:
                            self.init_f[row][column] = 1
                    else:
                        if i + j < N:
                            self.init_f[row][column] = 2
                        else:
                            self.init_f[row][column] = 0
    def evaluation(self,X,weight,g,f,v,srt):
        g,f,v = default_f(self.server_num,X,self.init_f,weight)
        return g,f,v
class MOEAD:
    def __init__(self,ObjFunc,stepLength=299, T=10, maxGeneration=10):
        """
        :param populationSize: population size
        :param T: the closest T weight vectors
        """
        self.objFunc = ObjFunc.evaluation
        self.dimension = ObjFunc.dimension
        self.objFuncNum = ObjFunc.objFuncNum
        self.isMin = ObjFunc.isMin
        self.Mu = ObjFunc.Mu
        self.server_num = ObjFunc.server_num
        self.stepLength = stepLength
        self.T = T
        self.maxGeneration = maxGeneration
        self.Init()

    def Tchebycheff(self, Y, Lambda, Z):
        """
        切比雪夫公式（值都为向量）
        :param Y: objective value
        :param Lambda: weight
        :param Z: min value
        :return:
        """
        Lambda = [0.01 if item == 0 else item for item in Lambda]
        tchebycheff = np.max(np.abs(Y - Z) * Lambda)


        return tchebycheff

    def getFuncValue(self, X,weight=[0.5,0.5],g=np.array([10000,10000,10000]),f=None,v=None,srt=None):
        return self.objFunc(X,weight,g,f,v,srt)
    def produce_pop(self,population_size):
        pop = list()
        for i in range(population_size):
          pop.append(get_permutation(self.Mu,self.server_num))
        return np.array(pop)
    def Init(self):
        self.weights = produceWeight(2, self.stepLength)
        self.populationSize = self.weights.shape[0]
        self.population = self.produce_pop(self.populationSize)
        self.population_value = []
        self.srt = []
    def updateZ(self, Z, individualY):
        for i in range(Z.shape[0]):
            if individualY[i] < Z[i]:
                Z[i] = individualY[i]
        return Z

    def neighbor(self):
        B = []
        weights_copy = copy.deepcopy(self.weights)
        for i in range(self.weights.shape[0]):
            distance = (np.sum((self.weights - weights_copy[i]) ** 2, axis=1))
            indexSort = np.argsort(distance)
            B.append(list(indexSort[:self.T]))
        return B

    def getZ(self):
        Z,f,v = self.getFuncValue(self.population[0],self.weights[0])
        self.population_value.append([copy.deepcopy(Z),copy.deepcopy(f)])
        self.srt.append(f2SRT(self.population[0],copy.deepcopy(f),self.server_num))
        for i in range(1, self.populationSize):
            iValue,f,v= self.getFuncValue(self.population[i],self.weights[i],f=self.population_value[i-1][1],srt=self.srt[i-1])
            self.population_value.append([copy.deepcopy(iValue),copy.deepcopy(f)])
            self.srt.append(f2SRT(self.population[i], copy.deepcopy(f), self.server_num))
            for j in range(Z.shape[0]):
                if iValue[j] < Z[j]:
                    Z[j] = iValue[j]
        return Z


    def geneOp(self, individualA, individualB,p=False):
        n = len(individualA)
        temp1 = copy.deepcopy(individualA)
        temp2 = copy.deepcopy(individualB)
        if p==False:
            exchange_prob = gv.exchange_prob
        else:
            exchange_prob = 1
        if random.random()<exchange_prob:
            if n<=2:
                temp1[0] = temp2[0]
                temp2[0] = individualA[0]
                return temp1,temp2
            if (individualB==individualA).all()==True:
                temp1 = get_permutation(individualA,n)
                temp2 = get_permutation(individualB,n)
                return temp1, temp2
            startXorPoint = random.randint(0,n-2)
            XorLength = random.randint(1,np.max([1, n - startXorPoint-1]))
            if XorLength == n:
              XorLength = n - 1
            endXorPoint = startXorPoint + XorLength - 1
            Part1 = individualA[startXorPoint:endXorPoint+1]
            Part2 = individualB[startXorPoint:endXorPoint+1]
            temp1[startXorPoint: endXorPoint+1] = -np.ones([1, endXorPoint - startXorPoint + 1])
            temp2[startXorPoint: endXorPoint+1] = -np.ones([1, endXorPoint - startXorPoint + 1])
            flag = True
            while flag ==True:
                flag = False
                for j in range(XorLength):
                    index1 = np.where(temp1 == Part2[j])

                    if len(index1[0]) !=0:
                        temp1[index1] = Part1[j]
                        flag =True

                    index2 = np.where(temp2 == Part1[j])

                    if len(index2[0]) != 0:
                        temp2[index2] = Part2[j]
                        flag = True
            temp1[startXorPoint: endXorPoint + 1] = Part2
            temp2[startXorPoint: endXorPoint + 1] = Part1


        if random.random() < gv.mutation_prob:
            mutataion_position_1 = np.array([random.randint(0, n - 1) for i in range(gv.mutation_size)])
            t = temp1[mutataion_position_1[0]]
            for p_count in range(gv.mutation_size-1):
                temp1[mutataion_position_1[p_count]] = temp1[mutataion_position_1[p_count+1]]
            temp1[mutataion_position_1[gv.mutation_size-1]] = t

        if random.random() < gv.mutation_prob:
            mutataion_position_2 = np.array([random.randint(0, n - 1) for i in range(gv.mutation_size)])
            t = temp2[mutataion_position_2[0]]
            for p_count in range(gv.mutation_size - 1):
                temp2[mutataion_position_2[p_count]] = temp2[mutataion_position_2[p_count + 1]]
            temp2[mutataion_position_2[gv.mutation_size - 1]] = t

        if (temp1 == temp2).all() == True:
            temp1 = get_permutation(individualA, n)
            temp2 = get_permutation(individualB, n)
            return temp1, temp2
        return temp1,temp2

    def isDominated(self, p, q):
        if (p <= q).all() and (p != q).any():
            return True
        return False
    def run(self):
        HV_list = list()
        old_HV = -1
        HV_count = 0
        break_count = 0
        B = self.neighbor()
        Z = self.getZ()
        EP = []
        EP_ind = []
        EP_f = []
        for geneNum in range(self.maxGeneration):
            for i in range(self.populationSize):
                print('\r generation: (',(geneNum + 1),'/',self.maxGeneration,')',', individual: (',(i+1),'/',self.populationSize,')',end='')
                k, l = random.sample(B[i], 2)
                childA, childB = self.population[k], self.population[l]
                childA, childB = self.geneOp(childA, childB)
                YA,fA ,vA= self.getFuncValue(childA,self.weights[k],f=self.population_value[k][1],srt=self.srt[i])#g f v
                YB, fB ,vB= self.getFuncValue(childB, self.weights[l],f=self.population_value[l][1],srt=self.srt[i])
                if self.isDominated(YA, YB):
                    betterIndividual = childA
                    betterY = YA
                    betterf = fA
                    betterv = vA
                    Z = self.updateZ(Z, YA)
                else:
                    betterIndividual = childB
                    betterY = YB
                    betterf = fB
                    betterv = vB
                    Z = self.updateZ(Z, YB)
                for j in range(self.T):
                    individualJValue = copy.deepcopy(self.population_value[B[i][j]][0])
                    TBJ = self.Tchebycheff(individualJValue, self.weights[B[i][j]], Z)
                    TBB = self.Tchebycheff(betterY, self.weights[B[i][j]], Z)
                    if TBB < TBJ:
                         self.population[B[i][j]] = betterIndividual
                         self.population_value[B[i][j]] = [betterY,betterf,betterv]
                if len(EP) == 0:
                    EP.append(betterY)
                    EP_ind.append(betterIndividual)
                    EP_f.append(betterf)
                else:
                    isDominated = True
                    reList = []
                    reList_ind = []
                    reList_f = []
                    for j in range(len(EP)):
                        if self.isDominated(EP[j], betterY) or (EP[j] == betterY).all():
                            isDominated = False
                            break
                        elif not self.isDominated(betterY, EP[j]):
                            reList.append(EP[j])
                            reList_ind.append(EP_ind[j])
                            reList_f.append(EP_f[j])
                    if isDominated:
                        EP = copy.deepcopy(reList)
                        EP.append(betterY)

                        EP_ind = copy.deepcopy(reList_ind)
                        EP_ind.append(betterIndividual)

                        EP_f = copy.deepcopy(reList_f)
                        EP_f.append(betterf)
            HV_DPS = ea.indicator.HV(np.array(EP),gv.rf)
            if np.abs(HV_DPS-old_HV)<=0.001:
                HV_count = HV_count+1
                break_count = break_count+1
                if break_count >= 9:
                    HV_list.append(HV_DPS)
                    break
                if HV_count>=3:
                    # increase mutation probability
                    gv.mutation_size=gv.mutation_size+1
                    if gv.mutation_size > len(self.Mu):
                        gv.mutation_size = len(self.Mu)
                    gv.mutation_prob = gv.mutation_prob+0.01*2
                    HV_count=0
            else:
                break_count=0
                HV_count=0
            old_HV = HV_DPS
            print('\n Iteration=', (geneNum+1), ' HV=',str(HV_DPS),' HV_count=',str(HV_count),'break_count=',str(break_count),'\n')
            HV_list.append(HV_DPS)
        gv.mutation_prob=0.1
        gv.mutation_size = 2
        EP = np.array([np.array(item) for item in EP ])
        EP_ind = np.array([np.array(item) for item in EP_ind])
        EP_f = np.array([np.array(item) for item in EP_f])
        return EP,EP_ind,EP_f

def judgeDuplicated(array):
    ar = array.copy()
    ar.sort()
    count = 0
    while count < len(ar) - 1:
        if ar[count] == ar[count + 1]:
            return True
        else:
            count += 1
    return False